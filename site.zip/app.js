/* King Pizza Makers — static GitHub Pages build: WhatsApp order requests only. */
'use strict';

const STORE = {
  name:'King Pizza Makers', currency:'INR', phone:'9759495433',
  address:'Jahangirabad Chungi, Shikarpur, Bulandshahr', whatsappNumber:'919759495433',
  deliveryFee:0, freeDeliveryAt:0, coupon:{code:'KING10',percent:10}, actualOrdersEnabled:true
};
const DEMO_PRODUCTS = MENU_PRODUCTS;
const categoryMeta = [
  {id:'all',title:'All items',icon:'✨'},
  {id:'pizza',title:'Pizzas',icon:'🍕'},
  {id:'combos',title:'Combo Offers',icon:'🎉'},
  {id:'burgers',title:'Burgers',icon:'🍔'},
  {id:'momos',title:'Momos',icon:'🥟'},
  {id:'chinese',title:'Chinese',icon:'🥡'},
  {id:'garlic-bread',title:'Garlic bread',icon:'🥖'},
  {id:'fries',title:'Fries',icon:'🍟'},
  {id:'pasta',title:'Pasta',icon:'🍝'},
  {id:'sandwiches',title:'Sandwiches & wraps',icon:'🥪'},
  {id:'drinks',title:'Drinks',icon:'🥤'},
  {id:'mojitos',title:'Mojitos',icon:'🍹'},
  {id:'shakes',title:'Shakes',icon:'🥛'},
  {id:'desserts',title:'Desserts',icon:'🍨'},
];
const pizzaSubcategories = ['classics','favourites','loaded','signatures'];
const isPizza = p => p.type==='pizza';
const isCombo = p => p.type==='combo';
const comboChoiceLabel = (p,choice) => (p.comboOptions||[]).find(opt=>opt.value===choice)?.label||'';
const hasStartingCombos = () => cart.some(line=>getProduct(line.id)?.startingPrice);
const matchesCategory=(p,category)=>category==='all'||(category==='pizza'&&isPizza(p))||p.category===category;
const productOptionText = (p,line)=>isCombo(p)?`Combo: ${comboChoiceLabel(p,line.options?.choice)||'Set meal'}${p.startingPrice?' (starting-price estimate)':''}`:isPizza(p)?`Size: ${line.options.size}`:p.portion?`Portion: ${p.portion}`:'';

// Verified menu add-on prices indexed Regular/Medium/Large.
const cheeseExtras = [
  {id:'extra-cheese',label:'Extra Cheese',prices:[40,60,80]},
  {id:'cheese-burst',label:'Cheese Burst',prices:[40,60,90]},
];
// SPA page flags are updated by the router on navigation, without reinitialising the cart.
let isHome = false, isMenu = false, isCombos = false, isProduct = false;
function updatePageFlags(route){
 isHome=route==='home';isMenu=route==='menu';isCombos=route==='combos';isProduct=route==='product';
}

const formatPrice = value => new Intl.NumberFormat('en-IN',{style:'currency',currency:STORE.currency,maximumFractionDigits:0}).format(value);
const byId = id => document.getElementById(id);
const whatsappLink = text => `https://wa.me/${STORE.whatsappNumber}?text=${encodeURIComponent(text)}`;
const safe = text => String(text).replace(/[&<>"']/g, c => ({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]));

let cart = [];
try {
  const saved = JSON.parse(localStorage.getItem('kpm-cart-v3') || '[]');
  if (Array.isArray(saved)) cart = saved.filter(x=> DEMO_PRODUCTS.some(p=>p.id===x.id) && Number.isInteger(x.qty) && x.qty>0 && x.qty<=99 && Number.isFinite(x.unitPrice) && x.unitPrice>=0).map(x=>({...x,qty:Math.min(x.qty,50)})).filter(x=>{const p=DEMO_PRODUCTS.find(p=>p.id===x.id);const sizeIndex=p.sizes.findIndex(s=>s[0]===x.options?.size);if(sizeIndex<0)return false;if(isCombo(p) && ((p.comboOptions||[]).length?!comboChoiceLabel(p,x.options?.choice):(x.options?.choice||'')!==''))return false;const extras=x.options?.extras||[];if(!Array.isArray(extras)||extras.some(label=>!isPizza(p)||!cheeseExtras.some(e=>e.label===label)))return false;const unit=p.sizes[sizeIndex][1]+(isPizza(p)?cheeseExtras.reduce((sum,e)=>sum+(extras.includes(e.label)?e.prices[sizeIndex]:0),0):0);x.unitPrice=unit;return true});
} catch (_) { cart=[]; }
let state = {category:'all',search:'',sort:'featured',mode:'delivery',promo:'',activeModal:null,detail:null,latestOrder:null,orderUrl:null,reviewUrl:null};
let toastTimer;

function saveCart(){try{localStorage.setItem('kpm-cart-v3',JSON.stringify(cart));}catch(_){/* Local storage can be disabled */}}
function showToast(message){const toast=byId('toast');toast.textContent=message;toast.classList.add('show');clearTimeout(toastTimer);toastTimer=setTimeout(()=>toast.classList.remove('show'),2500)}
function getProduct(id){return DEMO_PRODUCTS.find(p=>p.id===id)}
function basketCount(){return cart.reduce((n,x)=>n+x.qty,0)}
function subtotal(){return cart.reduce((n,x)=>n+x.qty*x.unitPrice,0)}
function discount(){return state.promo===STORE.coupon.code ? Math.round(subtotal()*STORE.coupon.percent/100) : 0}
function deliveryCharge(){return state.mode==='pickup'||subtotal()>=STORE.freeDeliveryAt ? 0 : STORE.deliveryFee}
function total(){return Math.max(0,subtotal()-discount()+deliveryCharge())}
function estimatedAdvance(){return Math.ceil(total() * 0.20)}
function renderHeaderCart(){document.querySelector('.mobile-cart').classList.toggle('has-items',basketCount()>0);byId('cart-count').textContent=basketCount();byId('mobile-cart-count').textContent=`${basketCount()} item${basketCount()===1?'':'s'}`;byId('mobile-cart-price').innerHTML=`${formatPrice(subtotal())} <span>↗</span>`;}

function renderCategories(){if(!byId('category-filters'))return;
  let items=[...categoryMeta];
  if(pizzaSubcategories.includes(state.category))items.splice(2,0,{id:state.category,title:state.category[0].toUpperCase()+state.category.slice(1)+' pizzas',icon:'🍕'});
  byId('category-filters').innerHTML=items.map(c=>`<button type="button" class="category-pill ${c.id===state.category?'active':''}" data-category="${c.id}" aria-pressed="${c.id===state.category}"><span>${c.icon}</span>${c.title}</button>`).join('')
}
function productBadge(p){
  if(p.portion)return p.portion;
  if(isCombo(p))return p.startingPrice?'Starting price · confirm by phone':'Combo offer';
  if(!isPizza(p))return p.category.replace(/-/g,' ').replace(/\b\w/g,c=>c.toUpperCase());
  const spicy=/chilli|jalapeno|paprika|pepper|achari|teekha/i.test(p.ingredients);
  return p.category==='signatures'?'Signature pizza':spicy?'Spicy toppings':p.category==='classics'?'Classic pizza':'Veg pizza';
}

function renderPromoComboCard(p){
 const meta={
  'combo-family-fun':['red','FAMILY FAVORITE','Family Fun','Meal'],
  'combo-student-special':['purple','STUDENT DEAL','Student Special','Meal'],
  'combo-party-meal':['green','PARTY FAVORITE','Meal for','Party'],
  'combo-single-topping':['blue','PIZZA SPECIAL','Single Topping','Pizza'],
  'combo-veg-single':['amber','FUN MEAL','Fun Meal Veg','Single Combo'],
  'combo-veg-double':['berry','DOUBLE TOPPINGS','Fun Meal Veg','Double Combo']
 }[p.id]||['red','SPECIAL OFFER',p.name,''];
 const href=`index.html#/product?id=${encodeURIComponent(p.id)}`;
 const money=formatPrice(p.sizes[0][1]);
 const starting=!!p.startingPrice;
 const items=(p.comboItems||[]).map(item=>`<li>${safe(item)}</li>`).join('');
 return `<article class="royal-combo-card promo-card theme-${meta[0]}" data-combo-id="${safe(p.id)}">
 <a class="royal-combo-media promo-photo" href="${href}" aria-label="Explore ${safe(p.name)} for ${money}">
  <img src="${p.image}" alt="Representative food photography for ${safe(p.name)}" loading="lazy" width="1200" height="750" />
  <span class="promo-photo-shade" aria-hidden="true"></span>
  <span class="promo-photo-header"><span class="promo-brand"><span aria-hidden="true">♛</span> KING PIZZA MAKERS</span><span class="promo-price"><small>${starting?'FROM':'MEAL FOR'}</small><strong>${money}</strong></span></span>
  <span class="promo-photo-bottom"><span class="promo-photo-kicker">${meta[1]}</span><span class="promo-photo-title">${safe(meta[2])}<br/><em>${safe(meta[3])}</em></span><span class="promo-photo-view">Explore this offer <span aria-hidden="true">↗</span></span></span>
 </a>
 <div class="royal-combo-body promo-body"><span class="eyebrow">${starting?'STARTING PRICE · CONFIRM ON CALL':'COMPLETE MEAL OFFER'}</span>
 <h3>${safe(p.name)}</h3><div class="promo-items-label">${starting?'CHOOSE ONE OPTION':'WHAT’S INCLUDED'}</div><ol class="promo-meal-list ${starting?'choose-list':'include-list'}">${items}</ol>
 <p class="royal-combo-note">${safe(p.comboNote||'')}</p><div class="royal-combo-actions"><span class="promo-bottom-price"><small>${starting?'From':'Offer price'}</small><strong>${money}</strong></span><a class="btn btn-primary" href="${href}">Choose offer <span aria-hidden="true">↗</span></a></div>
 </div></article>`;
}

function renderCard(p){if(isCombo(p))return renderPromoComboCard(p);
 const priceText=isCombo(p)?(p.startingPrice?'Starting offer price • final price on callback':'Offer bundle · select options'):(isPizza(p)?`R ${formatPrice(p.sizes[0][1])} · M ${formatPrice(p.sizes[1][1])} · L ${formatPrice(p.sizes[2][1])}`:(p.portion?`${p.portion} per serving`:'One serving'));
 return `<article class="product-card"><div class="product-image-wrap"><span class="product-badge ${p.tone}">${safe(p.tag)}</span><span class="photo-type-badge">${safe(productBadge(p))}</span><a class="product-image-button" href="index.html#/product?id=${encodeURIComponent(p.id)}" aria-label="View ${safe(p.name)} details"><img src="${p.image}" alt="Representative image of ${safe(p.name)}" loading="lazy"/></a></div><div class="product-body"><span class="product-type"><span class="veg-label" aria-label="Vegetarian"></span> &nbsp; KING PIZZA MAKERS · ${safe(isPizza(p)?'PIZZA':p.category.replace(/-/g,' ').toUpperCase())}</span><h3><a class="product-title-button" href="index.html#/product?id=${encodeURIComponent(p.id)}">${safe(p.name)}</a></h3><p class="product-description">${safe(p.description)}</p><div class="size-hint">${safe(priceText)}</div><div class="product-footer"><span class="price">${formatPrice(p.sizes[0][1])}<small>${isPizza(p)||p.startingPrice?'Starting from':isCombo(p)?'Combo price':'Menu price'}</small></span><a href="index.html#/product?id=${encodeURIComponent(p.id)}" class="quick-add" aria-label="View ${safe(p.name)}">↗</a></div></div></article>`
}
function renderProducts(){if(!byId('product-grid'))return;
 let items=DEMO_PRODUCTS.filter(p=>matchesCategory(p,state.category)&&`${p.name} ${p.description} ${p.category}`.toLowerCase().includes(state.search.toLowerCase().trim()));
 if(state.sort==='low')items.sort((a,b)=>a.sizes[0][1]-b.sizes[0][1]);
 if(state.sort==='high')items.sort((a,b)=>b.sizes[0][1]-a.sizes[0][1]);
 if(state.sort==='az')items.sort((a,b)=>a.name.localeCompare(b.name));
 const fullCount=items.length;if(isHome&&state.category==='all'&&!state.search){const featured=['margherita','spicy-paneer','aloo-tikki-burger','cheese-burger','classic-pasta','chilli-potato','steam-momos','cold-coffee'];items=featured.map(getProduct).filter(Boolean);} else if(isHome)items=items.slice(0,8);
 byId('results-label').textContent=isHome && fullCount>items.length ? `Showing ${items.length} featured items · ${fullCount} on menu` : `${fullCount} item${fullCount===1?'':'s'}`;
 byId('empty-results').hidden=fullCount!==0;
 byId('product-grid').classList.toggle('all-combos',Boolean(items.length)&&items.every(isCombo));
 byId('product-grid').innerHTML=items.map(renderCard).join('');
}
function getDetailPrice(){const d=state.detail;if(!d)return 0;const p=getProduct(d.id);return p.sizes[d.size][1]+(isPizza(p)?cheeseExtras.reduce((n,e)=>n+(d.extras.includes(e.id)?e.prices[d.size]:0),0):0)}
function renderDetail(){
 const d=state.detail;if(!d)return;
 const p=getProduct(d.id);if(!p)return;
 const pizza=isPizza(p);
 const combo=isCombo(p);
 const sizeChoices=pizza?`<div class="detail-section"><div class="detail-section-title">Choose your pizza size <small>Required</small></div><div class="options-row">${p.sizes.map((s,i)=>`<button class="option-btn ${d.size===i?'active':''}" type="button" data-size="${i}" aria-pressed="${d.size===i}">${safe(s[0])}<small>${formatPrice(s[1])}</small></button>`).join('')}</div></div>`:`<div class="detail-section"><div class="detail-section-title">Menu price</div><div class="fixed-portion"><strong>${formatPrice(p.sizes[0][1])}</strong><span>${p.portion?safe(p.portion):'Per serving'}</span></div></div>`;
 const comboChoices=combo?`<div class="detail-section">${(p.comboItems||[]).length?`<div class="combo-includes"><div class="detail-section-title">${safe(p.startingPrice?'Available options':'This combo includes')}</div><ol class="combo-ordered-list">${p.comboItems.map(item=>`<li>${safe(item)}</li>`).join('')}</ol></div>`:''}<div class="detail-section-title">${safe(p.comboPrompt||'Offer details')}</div>${(p.comboOptions||[]).length?`<label class="combo-select-label"><select id="combo-select" aria-label="${safe(p.comboPrompt)}">${p.comboOptions.map(o=>`<option value="${safe(o.value)}" ${d.choice===o.value?'selected':''}>${safe(o.label)}</option>`).join('')}</select></label>`:`<p class="combo-static">This combo includes the fixed meal items shown.</p>`}<p class="combo-confirm-note">${safe(p.comboNote)} 20% advance is estimated; the restaurant confirms prices and changes by callback.</p></div>`:'';
 const cheeseChoices=pizza?`<div class="detail-section"><div class="detail-section-title">Cheese upgrades <small>Prices vary by size</small></div><div class="extra-list">${cheeseExtras.map((e,i)=>`<label class="extra-option"><input type="checkbox" data-extra="${i}" ${d.extras.includes(e.id)?'checked':''}/>${safe(e.label)}<small>+${formatPrice(e.prices[d.size])}</small></label>`).join('')}</div></div>`:'';
 const content=`<div class="product-detail"><div class="detail-art"><img src="${p.image}" alt="Representative image of ${safe(p.name)}"/></div><div class="detail-content"><span class="eyebrow">KING PIZZA MAKERS / ${safe(pizza?'PIZZA':'FULL MENU')}</span><h2 id="product-modal-title">${safe(p.name)}</h2><p class="ingredients-list"><strong>${pizza?'Ingredients & toppings:':'Item details:'}</strong> ${safe(p.description)}${p.portion?` · ${safe(p.portion)}`:''}</p>${combo?`<div class="fixed-portion combo-base-price"><strong>${p.startingPrice?'From ':''}${formatPrice(p.sizes[0][1])}</strong><span>${p.startingPrice?'Starting estimate • confirm before advance':'Poster bundle price'}</span></div>${comboChoices}`:sizeChoices+cheeseChoices}<div class="detail-bottom"><div class="qty-control"><button type="button" data-detail-qty="-1" aria-label="Decrease quantity">−</button><span>${d.qty}</span><button type="button" data-detail-qty="1" aria-label="Increase quantity">+</button></div><button class="btn btn-primary" type="button" id="add-to-cart">Add to basket · ${formatPrice(getDetailPrice()*d.qty)} <span>↗</span></button></div></div></div>`;
 const target=isProduct&&byId('product-page-content')?byId('product-page-content'):byId('product-modal-content');target.innerHTML=content;
 if(isProduct){document.title=`${p.name} | King Pizza Makers`;byId('breadcrumb-name').textContent=p.name;}
}
function openDetail(id){const p=getProduct(id);if(!p)return;state.detail={id,size:0,extras:[],qty:1,choice:(p.comboOptions||[])[0]?.value||''};renderDetail();if(!isProduct)openModal('product-modal')}
function addToCart(){const d=state.detail;if(!d)return;const p=getProduct(d.id);if(!p)return;
 const options={size:p.sizes[d.size][0],crust:'',extras:(isPizza(p)?d.extras.map(id=>cheeseExtras.find(e=>e.id===id)?.label).filter(Boolean):[]),choice:isCombo(p)?d.choice:''};
 const key=JSON.stringify([d.id,options.size,options.extras.slice().sort(),options.choice]);
 let line=cart.find(x=>x.key===key);if(line)line.qty=Math.min(50,line.qty+d.qty);else cart.push({key,id:d.id,options,qty:d.qty,unitPrice:getDetailPrice()});
 saveCart();renderHeaderCart();if(!isProduct)closeModal();showToast(`${p.name} added to basket`);
 if(isProduct)openCart();
}
function openModal(id){state.activeModal=id;byId('overlay').hidden=false;[byId('product-modal'),byId('checkout-modal'),byId('cart-drawer')].forEach(m=>m.hidden=m.id!==id);document.body.classList.add('modal-open');const close=byId(id).querySelector('[data-close-modal]');if(close)close.focus()}
function closeModal(){state.activeModal=null;byId('overlay').hidden=true;[byId('product-modal'),byId('checkout-modal'),byId('cart-drawer')].forEach(m=>m.hidden=true);document.body.classList.remove('modal-open')}
function renderCart(){
 byId('drawer-count').textContent=`(${basketCount()})`;
 if(!cart.length){byId('cart-items').innerHTML=`<div class="empty-cart"><span class="empty-emoji">🍕</span><h3>Something's missing...</h3><p>Your basket is waiting for delicious company.</p><button class="btn btn-primary" id="back-to-menu" type="button">Explore our menu ↗</button></div>`;byId('cart-bottom').innerHTML='';return;}
 byId('cart-items').innerHTML=cart.map((line,i)=>{const p=getProduct(line.id);if(!p)return '';const optionText=[...(isPizza(p)?[line.options?.size]:[]),...(isCombo(p)?[comboChoiceLabel(p,line.options?.choice)||'Set meal',...(p.startingPrice?['From-price estimate']:[])]:[]),...(p.portion?[p.portion]:[]),...(line.options?.extras||[])].filter(Boolean).map(safe).join(' • ')||'Standard';return `<div class="cart-item"><img src="${p.image}" alt=""/><div class="cart-item-info"><strong>${safe(p.name)}</strong><small>${optionText}</small><span class="price">${formatPrice(line.unitPrice*line.qty)}</span></div><div class="cart-item-actions"><div class="qty-control"><button type="button" data-cart-qty="${i}" data-delta="-1" aria-label="Remove one ${safe(p.name)}">−</button><span>${line.qty}</span><button type="button" data-cart-qty="${i}" data-delta="1" aria-label="Add one ${safe(p.name)}">+</button></div><button type="button" class="remove-item" data-remove="${i}" aria-label="Remove ${safe(p.name)}">×</button></div></div>`}).join('');
 byId('cart-bottom').innerHTML=`<div class="order-method"><button type="button" data-mode="delivery" class="${state.mode==='delivery'?'active':''}">🚴 Delivery</button><button type="button" data-mode="pickup" class="${state.mode==='pickup'?'active':''}">🛍 Pickup</button></div><div class="summary-row"><span>Menu subtotal</span><strong>${formatPrice(subtotal())}</strong></div><div class="summary-row"><span>Delivery</span><strong>${state.mode==='pickup'?'Pickup':'Verify service area'}</strong></div><div class="summary-row total"><span>Estimated total</span><strong>${formatPrice(total())}</strong></div><div class="summary-row advance"><span>20% advance required*</span><strong>${formatPrice(estimatedAdvance())}</strong></div><button class="btn btn-primary" id="checkout-button" type="button">Choose how to order <span>↗</span></button><p class="subnote">*Advance is estimated. Starting-price Fun Meals may cost more; the restaurant confirms contents, sizes, final prices and how to pay during the callback. No payment is taken on this page.</p>`;
}
function changeCartQty(index,delta){if(!cart[index])return;cart[index].qty+=delta;if(cart[index].qty<=0)cart.splice(index,1);else cart[index].qty=Math.min(50,cart[index].qty);saveCart();renderHeaderCart();renderCart()}
function openCart(){renderCart();openModal('cart-drawer')}
function renderCheckout(previous={}){
 if(!cart.length){closeModal();return;}
 const name=safe(previous.customerName||'');const phone=safe(previous.phone||'');
 const addr=safe(previous.address||'');const notes=safe(previous.notes||'');
 byId('checkout-content').innerHTML=`<div class="checkout-content"><span class="eyebrow">KING PIZZA MAKERS · NEW ORDER REQUEST</span><h2 id="checkout-title">Your order, <em>your way.</em></h2><p>Prepare your order request here, then send it on WhatsApp. Our team aims to call back within <strong>5 minutes</strong> when staff are available, to confirm changes, prices and the advance payment.</p><div class="checkout-tabs"><button type="button" data-checkout-mode="delivery" class="${state.mode==='delivery'?'active':''}">🚴 Delivery</button><button type="button" data-checkout-mode="pickup" class="${state.mode==='pickup'?'active':''}">🛍 Pickup</button></div><form id="checkout-form"><div class="form-grid"><label class="form-field">Full name *<input type="text" name="customerName" autocomplete="name" maxlength="80" required placeholder="Your full name" value="${name}" /></label><label class="form-field">Phone number *<input type="tel" name="phone" inputmode="tel" autocomplete="tel" required pattern="[0-9+ ()-]{10,18}" maxlength="18" placeholder="10-digit mobile number" value="${phone}" /></label>${state.mode==='delivery'?`<label class="form-field full">Delivery address *<textarea name="address" autocomplete="street-address" maxlength="300" required placeholder="House / shop no., street, locality and city">${addr}</textarea></label>`:''}<label class="form-field full">Special instructions (optional)<textarea name="notes" maxlength="300" placeholder="E.g. less spicy or delivery landmark">${notes}</textarea></label></div><div class="advance-panel"><div class="advance-panel-head"><span>20% advance payment required</span><strong>${formatPrice(estimatedAdvance())}</strong></div><div class="summary-row"><span>Estimated menu total</span><strong>${formatPrice(total())}</strong></div><div class="summary-row"><span>Estimated remaining balance (80%)</span><strong>${formatPrice(total()-estimatedAdvance())}</strong></div><p>Starting-price Fun Meals may cost more after option and size confirmation. Final total and advance may change if the restaurant confirms changes, taxes or delivery charges. The team will explain how to pay after calling you. <strong>No money is collected online here.</strong></p></div><label class="order-consent"><input type="checkbox" name="policy" required/> <span>I understand that this is an order request; the restaurant will confirm it by phone and 20% advance is required before acceptance. I agree to be contacted about this request.</span></label><div class="order-choice"><button class="btn btn-whatsapp" type="submit" id="whatsapp-order-button">Send request via WhatsApp ↗</button></div><p class="checkout-caution">To request an order, open WhatsApp and tap Send. Your request is not sent automatically. If you don't get a call, contact <a href="tel:+919759495433">9759495433</a>.</p></form></div>`;
}
function openCheckout(){renderCheckout();openModal('checkout-modal')}
function readOrderForm(form){
 if(!cart.length){showToast('Your basket is empty');return null}
 if(!form.reportValidity())return null;
 const d=new FormData(form);
 const fields={name:String(d.get('customerName')||'').trim(),phone:String(d.get('phone')||'').trim(),address:String(d.get('address')||'').trim(),notes:String(d.get('notes')||'').trim()};
 const digits=fields.phone.replace(/\D/g,'');
 if(!/^(91)?[6-9]\d{9}$/.test(digits)){showToast('Enter a valid Indian mobile number');return null}
 if(!fields.name || (state.mode==='delivery'&&!fields.address) || !d.get('policy')){showToast('Please fill required fields and accept the order policy');return null}
 state.checkoutFields={customerName:fields.name,phone:fields.phone,address:fields.address,notes:fields.notes};
 return fields;
}
function buildOrderMessage(fields,ref=''){
 const details=cart.map((line,i)=>{const p=getProduct(line.id);const extras=(line.options?.extras||[]).join(', ');return `${i+1}. ${p.name}\n   ${[productOptionText(p,line),extras?`Extras: ${extras}`:''].filter(Boolean).join(' | ')||'Standard serving'}\n   ${line.qty} × ${formatPrice(line.unitPrice)} = ${formatPrice(line.qty*line.unitPrice)}${isCombo(p)&&p.startingPrice?' (starting price, confirmation required)':''}${isCombo(p)&&p.comboNote?`\n   Note: ${p.comboNote}`:''}`}).join('\n');
 const method=state.mode==='pickup'?'Pickup':'Home delivery';
 return `Hello King Pizza Makers! 👑🍕\nI'd like to request an order. Please call me back (target: within 5 minutes, subject to staff availability) to confirm any changes and the final price.\n${ref?`*Website reference:* ${ref}\n`:''}\n*Customer:* ${fields.name}\n*Phone:* ${fields.phone}\n*Order type:* ${method}${fields.address?`\n*Delivery address:* ${fields.address}`:''}${fields.notes?`\n*Notes:* ${fields.notes}`:''}\n\n*ORDER ITEMS*\n${details}\n\n*Estimated menu total:* ${formatPrice(total())}\n*20% estimated advance required:* ${formatPrice(estimatedAdvance())}\n*Estimated remaining 80%:* ${formatPrice(total()-estimatedAdvance())}\n\nI understand the 20% advance is estimated on the displayed bundle or starting price and required before the order is accepted. Please confirm the final total, changes, delivery availability, payment instructions and callback. No payment has been made yet.`.replace(/\\n/g,'\n');
}
function prepareWhatsAppOrder(form){
 const fields=readOrderForm(form);if(!fields)return;
 const summary=buildOrderMessage(fields);
 state.latestOrder=summary;state.orderUrl=whatsappLink(summary);
 byId('checkout-content').innerHTML=`<div class="checkout-success"><div class="success-symbol whatsapp-symbol">✆</div><span class="eyebrow">WHATSAPP ORDER REQUEST</span><h2 id="checkout-title">Ready to <em>send.</em></h2><p>Your WhatsApp request is prepared. <strong>It has NOT been sent and is NOT confirmed.</strong> Open WhatsApp and tap Send. Staff aim to call back within 5 minutes if available to confirm final pricing, changes and your 20% advance payment.</p><div class="advance-panel mini"><div class="advance-panel-head"><span>20% estimated advance</span><strong>${formatPrice(estimatedAdvance())}</strong></div><p>Only pay after receiving verified instructions from the restaurant. No payment has been taken.</p></div><pre class="success-receipt" id="receipt-text"></pre><div class="success-buttons"><a class="btn btn-whatsapp" id="whatsapp-submit-link" target="_blank" rel="noopener noreferrer" href="${state.orderUrl}">Open WhatsApp &amp; send ↗</a><button class="btn btn-outline" id="copy-summary" type="button">Copy message ⧉</button><button class="btn btn-outline" id="edit-order" type="button">Edit details</button></div><p class="checkout-caution">If you don't hear back promptly, please call <a href="tel:+919759495433">9759495433</a>. Your basket remains saved.</p></div>`;
 byId('receipt-text').textContent=summary;
}
function prepareReview(form){
 const fd=new FormData(form), rating=Number(fd.get('rating'));
 const name=String(fd.get('reviewer')||'').trim();
 const feedback=String(fd.get('review')||'').trim();
 if(!rating||!feedback||!name){showToast('Please fill all review fields');return}
 const message=`Hello King Pizza Makers! I'd like to share feedback about my experience.\nName: ${name}\nRating: ${rating}/5\nFeedback: ${feedback}\n\nPlease review this feedback before any public publishing.`;
 const target=byId('review-result');target.hidden=false;
 target.innerHTML=`<strong>Your feedback is ready.</strong><p>It is not publicly posted or saved to this website. Open WhatsApp and tap Send.</p><a target="_blank" rel="noopener noreferrer" class="btn btn-whatsapp" href="${whatsappLink(message)}">Send feedback on WhatsApp ↗</a>`;
}
function copyText(text){if(navigator.clipboard?.writeText && window.isSecureContext){navigator.clipboard.writeText(text).then(()=>showToast('Copied to clipboard')).catch(()=>fallbackCopy(text));}else fallbackCopy(text)}
function fallbackCopy(text){const field=document.createElement('textarea');field.value=text;field.style.cssText='position:fixed;left:-9999px';document.body.appendChild(field);field.select();try{document.execCommand('copy');showToast('Copied to clipboard')}catch(_){showToast('Please copy manually')}field.remove()}

// Single event delegation makes search-generated cards and repeated modal renders reliable.
document.addEventListener('click',event=>{
 const button=event.target.closest('button');if(!button)return;
 if(button.hasAttribute('data-open-cart')){openCart();return}
 if(button.hasAttribute('data-close-modal')){closeModal();return}
 if(button.dataset.category!==undefined){state.category=button.dataset.category;renderCategories();renderProducts();return}
 if(button.dataset.product){openDetail(button.dataset.product);return}
 if(button.dataset.size!==undefined && state.detail){state.detail.size=Number(button.dataset.size);renderDetail();return}
  if(button.dataset.detailQty!==undefined && state.detail){state.detail.qty=Math.max(1,Math.min(50,state.detail.qty+Number(button.dataset.detailQty)));renderDetail();return}
 if(button.id==='add-to-cart'){addToCart();return}
 if(button.dataset.cartQty!==undefined){changeCartQty(Number(button.dataset.cartQty),Number(button.dataset.delta));return}
 if(button.dataset.remove!==undefined){cart.splice(Number(button.dataset.remove),1);saveCart();renderHeaderCart();renderCart();return}
 if(button.dataset.mode){state.mode=button.dataset.mode;renderCart();return}
 if(button.dataset.checkoutMode){const form=byId('checkout-form');const values=form?new FormData(form):null;const previous=values?Object.fromEntries(values.entries()):{};state.mode=button.dataset.checkoutMode;renderCheckout(previous);return}
 if(button.id==='checkout-button'){openCheckout();return}
 if(button.id==='edit-order'){renderCheckout(state.checkoutFields||{});return}
 if(button.id==='back-to-menu'||button.id==='finish-checkout'){closeModal();if(byId('menu'))byId('menu').scrollIntoView({behavior:'smooth'});else if(window.kpmNavigate)window.kpmNavigate('index.html#/menu');else location.href='index.html#/menu';return}
 if(button.id==='copy-summary'){copyText(state.latestOrder||'');return}
 if(button.id==='copy-coupon'){copyText(STORE.coupon.code);return}
 if(button.id==='reset-filters'){state.category='all';state.search='';if(byId('product-search'))byId('product-search').value='';renderCategories();renderProducts();return}
});
document.addEventListener('change',event=>{
 const input=event.target;
 if(input.id==='combo-select' && state.detail && isCombo(getProduct(state.detail.id))){state.detail.choice=input.value;renderDetail();return}
 if(input.dataset.extra!==undefined && state.detail && isPizza(getProduct(state.detail.id))){const id=cheeseExtras[Number(input.dataset.extra)].id;state.detail.extras=input.checked?[...state.detail.extras,id]:state.detail.extras.filter(x=>x!==id);renderDetail()}
});
document.addEventListener('submit',event=>{if(event.target.id==='checkout-form'){event.preventDefault();prepareWhatsAppOrder(event.target)}else if(event.target.id==='review-form'){event.preventDefault();prepareReview(event.target)}});
document.addEventListener('input',event=>{if(event.target.id==='product-search'){state.search=event.target.value;renderProducts()}});
document.addEventListener('change',event=>{if(event.target.id==='sort-select'){state.sort=event.target.value;renderProducts()}});
byId('overlay').addEventListener('click',closeModal);
document.addEventListener('keydown',event=>{if(event.key==='Escape' && state.activeModal){closeModal()}});
byId('year').textContent=new Date().getFullYear();
function kpmInitActiveRoute(route, url){
 updatePageFlags(route);
 // Reset route-only UI state, not the basket, order mode or applied coupon.
 state.category=isCombos?'combos':'all'; state.search='';state.sort='featured';state.detail=null;
 if(isMenu){const requested=new URLSearchParams(url.search).get('category');if(categoryMeta.some(c=>c.id===requested)||pizzaSubcategories.includes(requested))state.category=requested;}
 renderCategories();renderProducts();renderHeaderCart();
 if(isProduct){
   const requested=new URLSearchParams(url.search).get('id');const p=getProduct(requested);
   if(p){openDetail(p.id);const recommendations=DEMO_PRODUCTS.filter(x=>x.id!==p.id && (x.category===p.category || Math.abs(x.sizes[0][1]-p.sizes[0][1])<=50)).slice(0,4);
     byId('related-product-grid').innerHTML=recommendations.map(renderCard).join('');
   }else{byId('product-page-content').innerHTML=`<div class="not-found"><h1>That item isn’t on the menu.</h1><p>Please explore the complete King Pizza Makers menu.</p><a class="btn btn-primary" href="index.html#/menu">Explore the menu ↗</a></div>`;}
 }
}
window.kpmOnRouteChange=kpmInitActiveRoute;
kpmInitActiveRoute(window.kpmCurrentRoute||'home', window.kpmRouteURL||new URL(location.href));
