/* King Pizza Makers · Optional official Instagram embed and fallback. */
(function () {
  'use strict';
  document.addEventListener('click', function (event) {
    const trigger = event.target.closest('#kpm-load-instagram');
    if(!trigger) return;
    const target = document.getElementById('kpm-instagram-embed-container');
    const status = document.getElementById('kpm-instagram-embed-status');
    if (!target || !status || trigger.disabled) return;
    target.hidden = false;
    trigger.disabled = true;
    trigger.textContent = 'Loading public Instagram profile…';
    status.textContent = 'Requesting Instagram’s official embed. If the account restricts embeds, use Open live Instagram profile below.';
    function render() {
      try {
        if (window.instgrm && window.instgrm.Embeds && typeof window.instgrm.Embeds.process === 'function') {
          window.instgrm.Embeds.process();
          status.textContent = 'Instagram embed requested. Display depends on the public account’s embed settings and browser permissions.';
          trigger.textContent = 'Instagram preview requested';
        } else {
          status.textContent = 'Instagram embed isn’t available in this browser. Use Open live Instagram profile below.';
          trigger.textContent = 'Instagram preview unavailable';
        }
      } catch (_) {
        status.textContent = 'Instagram couldn’t render the profile here. The external Instagram link still works.';
        trigger.textContent = 'Instagram preview unavailable';
      }
    }
    if (window.instgrm && window.instgrm.Embeds) { render(); return; }
    const script = document.createElement('script');
    script.async = true;
    script.src = 'https://www.instagram.com/embed.js';
    script.onload = render;
    script.onerror = function () {
      status.textContent = 'Instagram blocked the embed. Open the live profile with the button below.';
      trigger.textContent = 'Instagram preview unavailable';
    };
    document.head.appendChild(script);
  });
})();
