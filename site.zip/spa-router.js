/* King Pizza Makers · TRUE single-index SPA.
   All public views live in index.html templates; no separate HTML pages or
   rewrite rules are required. Hash routes work on Hostinger and file previews.
   Header, basket, modal, backend request flow remain mounted between views. */
(() => {
  'use strict';
  const main=document.getElementById('kpm-spa-main');
  if (!main) return;
  const supported=new Set(['home','menu','combos','product','connect']);
  const titles={
    home:'King Pizza Makers | Fresh Pizza & More — Shikarpur',
    menu:'Full Menu | King Pizza Makers — 91 Listings',
    combos:'Combo Deals | King Pizza Makers',
    connect:'Visit Us | King Pizza Makers',
    product:'Product Details | King Pizza Makers'
  };
  const indexURL=()=>new URL('index.html',document.baseURI);
  function fromHash(hash=location.hash){
    if (!hash || !hash.startsWith('#/')) return {route:'home', query:'', anchor:'',key:'home'};
    const part=hash.slice(2);
    const q=part.indexOf('?');
    const path=(q<0?part:part.slice(0,q)).split('/').filter(Boolean);
    const route=supported.has(path[0])?path[0]:'home';
    const anchor=path.slice(1).join('/');
    const query=q<0?'':part.slice(q);
    return {route,query,anchor,key:`${route}/${anchor}${query}`};
  }
  function canonicalURL({route,query='',anchor=''}){
    const url=indexURL();
    const suffix=`/${route}${anchor?'/'+encodeURIComponent(anchor):''}${query}`;
    url.hash=suffix;
    return url;
  }
  function virtualURL(info){
    return new URL(`${info.route==='home'?'index':info.route}.html${info.query}`,document.baseURI);
  }
  function scrollToSection(anchor, smooth=false){
    requestAnimationFrame(()=>requestAnimationFrame(()=>{
      const target=anchor?document.getElementById(anchor):null;
      if (target) target.scrollIntoView({behavior:smooth?'smooth':'instant',block:'start'});
      else window.scrollTo({top:0,behavior:'instant'});
    }));
  }
  function updateNav(route){
    document.body.dataset.kpmPage=route;
    document.querySelectorAll('.nav-links a,.mobile-menu-nav,.mobile-connect-nav').forEach(a=>{
      const href=a.getAttribute('href')||'';
      const item=href.match(/#\/(menu|combos|connect)(?:[/?]|$)/)?.[1];
      const active=!!item&&item===route;
      a.classList.toggle('spa-route-current',active);
      if (active)a.setAttribute('aria-current','page'); else a.removeAttribute('aria-current');
    });
  }
  let lastRendered='';
  function render(info, force=false){
    const route=info.route;
    const isNew=force||info.key!==lastRendered;
    if (!isNew) return;
    const template=document.getElementById(`kpm-template-${route}`);
    if (!template) return;
    const oldRoute=(lastRendered.split('/')[0]||'');
    const oldQuery=lastRendered.split('?')[1]||'';
    const needReplace=force||oldRoute!==route||oldQuery!==info.query.slice(1)||route==='product';
    if (needReplace){
      // Cloned content is the only changing view. Global cart, forms and listeners remain mounted.
      main.replaceChildren(template.content.cloneNode(true));
      window.kpmCurrentRoute=route;
      window.kpmRouteURL=virtualURL(info);
      updateNav(route);
      document.title=titles[route];
      if(typeof window.kpmOnRouteChange==='function') window.kpmOnRouteChange(route,window.kpmRouteURL);
    }
    lastRendered=info.key;
    if(!needReplace && info.anchor) scrollToSection(info.anchor,true);
    else scrollToSection(info.anchor);
  }
  function readLink(href){
    if (!href || href.startsWith('javascript:')) return null;
    if (href.startsWith('#') && !href.startsWith('#/')){
      const info=fromHash(); const anchor=href.slice(1); return {...info,anchor,key:`${info.route}/${anchor}${info.query}`};
    }
    let dest;
    try{dest=new URL(href,location.href)}catch(_){return null}
    if(dest.origin!==location.origin || dest.pathname!==indexURL().pathname) return null;
    return fromHash(dest.hash);
  }
  function navigate(href){
    const info=readLink(href);
    if (!info)return false;
    const target=canonicalURL(info);
    if(target.href!==location.href)history.pushState({kpmSpa:true},'',target.href);
    render(info);
    return true;
  }
  window.kpmNavigate=navigate;
  document.addEventListener('click',event=>{
    if(event.defaultPrevented||event.button!==0||event.ctrlKey||event.metaKey||event.shiftKey||event.altKey)return;
    const a=event.target.closest('a[href]');
    if(!a||a.hasAttribute('download')||(a.target&&a.target!=='_self'))return;
    if(navigate(a.getAttribute('href')))event.preventDefault();
  });
  const sync=()=>render(fromHash());
  window.addEventListener('popstate',sync);
  window.addEventListener('hashchange',sync);
  render(fromHash(),true); // populate active template before app.js initializes
})();
