// Restaurant menu catalog: 20 pizzas from original CSV + new poster items and user price overrides.
// Product visuals are per-item editorial images based on generated food photography and supplied restaurant promotional photos; they are not independently verified photos of dishes.
const MENU_PRODUCTS = [
  {
    "id": "margherita",
    "name": "Margherita",
    "category": "classics",
    "tag": "Classic pick",
    "tone": "gold",
    "description": "Cheese, Onion, Capsicum",
    "image": "assets/products/margherita.webp",
    "sizes": [
      [
        "Regular",
        99
      ],
      [
        "Medium",
        169
      ],
      [
        "Large",
        279
      ]
    ],
    "ingredients": "Cheese, Onion, Capsicum",
    "type": "pizza",
    "portion": "",
    "source": "pizza-menu-csv"
  },
  {
    "id": "cheese-paneer",
    "name": "Cheese Paneer",
    "category": "classics",
    "tag": "Cheesy choice",
    "tone": "green",
    "description": "Cheese, Corn, Tomato",
    "image": "assets/products/cheese-paneer.webp",
    "sizes": [
      [
        "Regular",
        99
      ],
      [
        "Medium",
        169
      ],
      [
        "Large",
        279
      ]
    ],
    "ingredients": "Cheese, Corn, Tomato",
    "type": "pizza",
    "portion": "",
    "source": "pizza-menu-csv"
  },
  {
    "id": "cheese-tomato",
    "name": "Cheese Tomato",
    "category": "classics",
    "tag": "Family pick",
    "tone": "",
    "description": "Cheese, Capsicum, Tomato",
    "image": "assets/products/cheese-tomato.webp",
    "sizes": [
      [
        "Regular",
        99
      ],
      [
        "Medium",
        169
      ],
      [
        "Large",
        279
      ]
    ],
    "ingredients": "Cheese, Capsicum, Tomato",
    "type": "pizza",
    "portion": "",
    "source": "pizza-menu-csv"
  },
  {
    "id": "delight-special",
    "name": "Delight Special",
    "category": "favourites",
    "tag": "Pizza favourite",
    "tone": "gold",
    "description": "Onion, Capsicum, Sweet Corn",
    "image": "assets/products/delight-special.webp",
    "sizes": [
      [
        "Regular",
        129
      ],
      [
        "Medium",
        199
      ],
      [
        "Large",
        299
      ]
    ],
    "ingredients": "Onion, Capsicum, Sweet Corn",
    "type": "pizza",
    "portion": "",
    "source": "pizza-menu-csv"
  },
  {
    "id": "fresh-veggie",
    "name": "Fresh Veggie",
    "category": "favourites",
    "tag": "Fresh & vibrant",
    "tone": "green",
    "description": "Onion, Capsicum, Jalapeno",
    "image": "assets/products/fresh-veggie.webp",
    "sizes": [
      [
        "Regular",
        129
      ],
      [
        "Medium",
        199
      ],
      [
        "Large",
        299
      ]
    ],
    "ingredients": "Onion, Capsicum, Jalapeno",
    "type": "pizza",
    "portion": "",
    "source": "pizza-menu-csv"
  },
  {
    "id": "hungry-special",
    "name": "Hungry Special",
    "category": "favourites",
    "tag": "Crowd favourite",
    "tone": "",
    "description": "Onion, Capsicum, Sweet Corn",
    "image": "assets/products/hungry-special.webp",
    "sizes": [
      [
        "Regular",
        129
      ],
      [
        "Medium",
        199
      ],
      [
        "Large",
        299
      ]
    ],
    "ingredients": "Onion, Capsicum, Sweet Corn",
    "type": "pizza",
    "portion": "",
    "source": "pizza-menu-csv"
  },
  {
    "id": "mexican-veggie",
    "name": "Mexican Veggie",
    "category": "favourites",
    "tag": "A little kick",
    "tone": "gold",
    "description": "Onion, Jalapeno, Extra Cheese",
    "image": "assets/products/mexican-veggie.webp",
    "sizes": [
      [
        "Regular",
        139
      ],
      [
        "Medium",
        229
      ],
      [
        "Large",
        329
      ]
    ],
    "ingredients": "Onion, Jalapeno, Extra Cheese",
    "type": "pizza",
    "portion": "",
    "source": "pizza-menu-csv"
  },
  {
    "id": "farm-house",
    "name": "Farm House",
    "category": "favourites",
    "tag": "Farm fresh",
    "tone": "green",
    "description": "Onion, Capsicum, Tomato, Mushroom",
    "image": "assets/products/farm-house.webp",
    "sizes": [
      [
        "Regular",
        139
      ],
      [
        "Medium",
        229
      ],
      [
        "Large",
        329
      ]
    ],
    "ingredients": "Onion, Capsicum, Tomato, Mushroom",
    "type": "pizza",
    "portion": "",
    "source": "pizza-menu-csv"
  },
  {
    "id": "teekha-paneer",
    "name": "Teekha Paneer",
    "category": "favourites",
    "tag": "Paneer special",
    "tone": "",
    "description": "Red Paprika, Paneer, Capsicum",
    "image": "assets/products/teekha-paneer.webp",
    "sizes": [
      [
        "Regular",
        139
      ],
      [
        "Medium",
        229
      ],
      [
        "Large",
        329
      ]
    ],
    "ingredients": "Red Paprika, Paneer, Capsicum",
    "type": "pizza",
    "portion": "",
    "source": "pizza-menu-csv"
  },
  {
    "id": "shikarpur-lover",
    "name": "Shikarpur Lover",
    "category": "favourites",
    "tag": "Local favourite",
    "tone": "gold",
    "description": "Red Paprika, Paneer, Capsicum, Onion, Tomato",
    "image": "assets/products/shikarpur-lover.webp",
    "sizes": [
      [
        "Regular",
        139
      ],
      [
        "Medium",
        229
      ],
      [
        "Large",
        329
      ]
    ],
    "ingredients": "Red Paprika, Paneer, Capsicum, Onion, Tomato",
    "type": "pizza",
    "portion": "",
    "source": "pizza-menu-csv"
  },
  {
    "id": "deluxe-veggie",
    "name": "Deluxe Veggie",
    "category": "loaded",
    "tag": "Veg loaded",
    "tone": "green",
    "description": "Jalapeno, Paneer, Capsicum, Onion",
    "image": "assets/products/deluxe-veggie.webp",
    "sizes": [
      [
        "Regular",
        149
      ],
      [
        "Medium",
        249
      ],
      [
        "Large",
        349
      ]
    ],
    "ingredients": "Jalapeno, Paneer, Capsicum, Onion",
    "type": "pizza",
    "portion": "",
    "source": "pizza-menu-csv"
  },
  {
    "id": "five-pepper",
    "name": "Five Pepper",
    "category": "loaded",
    "tag": "Pepper favourite",
    "tone": "",
    "description": "Jalapeno, Capsicum, Red Pepper, Red Yellow Capsicum",
    "image": "assets/products/five-pepper.webp",
    "sizes": [
      [
        "Regular",
        149
      ],
      [
        "Medium",
        249
      ],
      [
        "Large",
        349
      ]
    ],
    "ingredients": "Jalapeno, Capsicum, Red Pepper, Red Yellow Capsicum",
    "type": "pizza",
    "portion": "",
    "source": "pizza-menu-csv"
  },
  {
    "id": "spicy-paneer",
    "name": "Spicy Paneer",
    "category": "loaded",
    "tag": "Spicy choice",
    "tone": "gold",
    "description": "Onion, Capsicum, Red Paprika, Paneer, Green Chilli",
    "image": "assets/products/spicy-paneer.webp",
    "sizes": [
      [
        "Regular",
        149
      ],
      [
        "Medium",
        249
      ],
      [
        "Large",
        349
      ]
    ],
    "ingredients": "Onion, Capsicum, Red Paprika, Paneer, Green Chilli",
    "type": "pizza",
    "portion": "",
    "source": "pizza-menu-csv"
  },
  {
    "id": "makhkhani-paneer",
    "name": "Makhkhani Paneer",
    "category": "signatures",
    "tag": "Signature",
    "tone": "green",
    "description": "Onion, Capsicum, Mushroom, Black Olive, Corn, Makhani Sauce",
    "image": "assets/products/makhkhani-paneer.webp",
    "sizes": [
      [
        "Regular",
        189
      ],
      [
        "Medium",
        349
      ],
      [
        "Large",
        499
      ]
    ],
    "ingredients": "Onion, Capsicum, Mushroom, Black Olive, Corn, Makhani Sauce",
    "type": "pizza",
    "portion": "",
    "source": "pizza-menu-csv"
  },
  {
    "id": "achari-pizza",
    "name": "Achari Pizza",
    "category": "signatures",
    "tag": "Signature",
    "tone": "",
    "description": "Onion, Capsicum, Jalapeno, Black Olive, Achari Sauce",
    "image": "assets/products/achari-pizza.webp",
    "sizes": [
      [
        "Regular",
        189
      ],
      [
        "Medium",
        349
      ],
      [
        "Large",
        499
      ]
    ],
    "ingredients": "Onion, Capsicum, Jalapeno, Black Olive, Achari Sauce",
    "type": "pizza",
    "portion": "",
    "source": "pizza-menu-csv"
  },
  {
    "id": "veg-supreme",
    "name": "Veg Supreme",
    "category": "signatures",
    "tag": "Signature",
    "tone": "gold",
    "description": "Onion, Capsicum, Jalapeno, Black Olive, Red Paprika, Corn, Paneer",
    "image": "assets/products/veg-supreme.webp",
    "sizes": [
      [
        "Regular",
        189
      ],
      [
        "Medium",
        349
      ],
      [
        "Large",
        499
      ]
    ],
    "ingredients": "Onion, Capsicum, Jalapeno, Black Olive, Red Paprika, Corn, Paneer",
    "type": "pizza",
    "portion": "",
    "source": "pizza-menu-csv"
  },
  {
    "id": "king-9-wonder",
    "name": "King 9 Wonder",
    "category": "signatures",
    "tag": "House special",
    "tone": "green",
    "description": "Onion, Capsicum, Jalapeno, Red Paprika, Baby Corn, Paneer",
    "image": "assets/products/king-9-wonder.webp",
    "sizes": [
      [
        "Regular",
        189
      ],
      [
        "Medium",
        349
      ],
      [
        "Large",
        499
      ]
    ],
    "ingredients": "Onion, Capsicum, Jalapeno, Red Paprika, Baby Corn, Paneer",
    "type": "pizza",
    "portion": "",
    "source": "pizza-menu-csv"
  },
  {
    "id": "pizza-pasta",
    "name": "Pizza Pasta",
    "category": "signatures",
    "tag": "Signature",
    "tone": "",
    "description": "Onion, Capsicum, Mushroom, Red Paprika, Baby Corn, Paneer, Black Olive",
    "image": "assets/products/pizza-pasta.webp",
    "sizes": [
      [
        "Regular",
        189
      ],
      [
        "Medium",
        349
      ],
      [
        "Large",
        499
      ]
    ],
    "ingredients": "Onion, Capsicum, Mushroom, Red Paprika, Baby Corn, Paneer, Black Olive",
    "type": "pizza",
    "portion": "",
    "source": "pizza-menu-csv"
  },
  {
    "id": "tandoori-special",
    "name": "Tandoori Special",
    "category": "signatures",
    "tag": "Tandoori",
    "tone": "gold",
    "description": "Tandoori Sauce, Onion, Capsicum, Tomato, Sweet Corn, Mushroom, Paneer",
    "image": "assets/products/tandoori-special.webp",
    "sizes": [
      [
        "Regular",
        189
      ],
      [
        "Medium",
        349
      ],
      [
        "Large",
        499
      ]
    ],
    "ingredients": "Tandoori Sauce, Onion, Capsicum, Tomato, Sweet Corn, Mushroom, Paneer",
    "type": "pizza",
    "portion": "",
    "source": "pizza-menu-csv"
  },
  {
    "id": "kulhad-pizza",
    "name": "Kulhad Pizza",
    "category": "signatures",
    "tag": "Specialty",
    "tone": "green",
    "description": "Cheese, Red Paprika, Jalapeno, Onion, Capsicum, Tomato, Sweet Corn, Mushroom, Paneer",
    "image": "assets/products/kulhad-pizza.webp",
    "sizes": [
      [
        "Regular",
        199
      ],
      [
        "Medium",
        299
      ],
      [
        "Large",
        499
      ]
    ],
    "ingredients": "Cheese, Red Paprika, Jalapeno, Onion, Capsicum, Tomato, Sweet Corn, Mushroom, Paneer",
    "type": "pizza",
    "portion": "",
    "source": "pizza-menu-csv"
  },
  {
    "id": "aloo-tikki-burger",
    "name": "Aloo Tikki Burger",
    "category": "burgers",
    "type": "burgers",
    "tag": "Burgers",
    "tone": "gold",
    "description": "Freshly prepared burger from the King Pizza Makers menu",
    "image": "assets/products/aloo-tikki-burger.webp",
    "sizes": [
      [
        "Standard",
        40
      ]
    ],
    "ingredients": "Freshly prepared burger from the King Pizza Makers menu",
    "portion": "",
    "source": "menu-poster"
  },
  {
    "id": "cheese-burger",
    "name": "Cheese Burger",
    "category": "burgers",
    "type": "burgers",
    "tag": "Burgers",
    "tone": "gold",
    "description": "Freshly prepared burger from the King Pizza Makers menu",
    "image": "assets/products/cheese-burger.webp",
    "sizes": [
      [
        "Standard",
        49
      ]
    ],
    "ingredients": "Freshly prepared burger from the King Pizza Makers menu",
    "portion": "",
    "source": "menu-poster"
  },
  {
    "id": "bombay-burger",
    "name": "Bombay Burger",
    "category": "burgers",
    "type": "burgers",
    "tag": "Burgers",
    "tone": "gold",
    "description": "Freshly prepared burger from the King Pizza Makers menu",
    "image": "assets/products/bombay-burger.webp",
    "sizes": [
      [
        "Standard",
        55
      ]
    ],
    "ingredients": "Freshly prepared burger from the King Pizza Makers menu",
    "portion": "",
    "source": "menu-poster"
  },
  {
    "id": "paneer-burger",
    "name": "Paneer Burger",
    "category": "burgers",
    "type": "burgers",
    "tag": "Burgers",
    "tone": "gold",
    "description": "Freshly prepared burger from the King Pizza Makers menu",
    "image": "assets/products/paneer-burger.webp",
    "sizes": [
      [
        "Standard",
        60
      ]
    ],
    "ingredients": "Freshly prepared burger from the King Pizza Makers menu",
    "portion": "",
    "source": "menu-poster"
  },
  {
    "id": "veg-surprise-burger",
    "name": "Veg Surprise Burger",
    "category": "burgers",
    "type": "burgers",
    "tag": "Burgers",
    "tone": "gold",
    "description": "Freshly prepared burger from the King Pizza Makers menu",
    "image": "assets/products/veg-surprise-burger.webp",
    "sizes": [
      [
        "Standard",
        70
      ]
    ],
    "ingredients": "Freshly prepared burger from the King Pizza Makers menu",
    "portion": "",
    "source": "menu-poster"
  },
  {
    "id": "paneer-makkhani-burger",
    "name": "Paneer Makkhani Burger",
    "category": "burgers",
    "type": "burgers",
    "tag": "Burgers",
    "tone": "gold",
    "description": "Freshly prepared burger from the King Pizza Makers menu",
    "image": "assets/products/paneer-makkhani-burger.webp",
    "sizes": [
      [
        "Standard",
        75
      ]
    ],
    "ingredients": "Freshly prepared burger from the King Pizza Makers menu",
    "portion": "",
    "source": "menu-poster"
  },
  {
    "id": "veg-king-burger",
    "name": "Veg King Burger",
    "category": "burgers",
    "type": "burgers",
    "tag": "Burgers",
    "tone": "gold",
    "description": "Freshly prepared burger from the King Pizza Makers menu",
    "image": "assets/products/veg-king-burger.webp",
    "sizes": [
      [
        "Standard",
        100
      ]
    ],
    "ingredients": "Freshly prepared burger from the King Pizza Makers menu",
    "portion": "",
    "source": "menu-poster"
  },
  {
    "id": "garlic-bread",
    "name": "Garlic Bread",
    "category": "garlic-bread",
    "type": "garlic-bread",
    "tag": "Garlic Bread",
    "tone": "",
    "description": "Toasted garlic bread from the restaurant menu",
    "image": "assets/products/garlic-bread.webp",
    "sizes": [
      [
        "Standard",
        65
      ]
    ],
    "ingredients": "Toasted garlic bread from the restaurant menu",
    "portion": "",
    "source": "menu-poster"
  },
  {
    "id": "stuffed-garlic-bread",
    "name": "Stuffed Garlic Bread",
    "category": "garlic-bread",
    "type": "garlic-bread",
    "tag": "Garlic Bread",
    "tone": "",
    "description": "Toasted garlic bread from the restaurant menu",
    "image": "assets/products/stuffed-garlic-bread.webp",
    "sizes": [
      [
        "Standard",
        80
      ]
    ],
    "ingredients": "Toasted garlic bread from the restaurant menu",
    "portion": "",
    "source": "menu-poster"
  },
  {
    "id": "cheese-garlic-bread",
    "name": "Cheese Garlic Bread",
    "category": "garlic-bread",
    "type": "garlic-bread",
    "tag": "Garlic Bread",
    "tone": "",
    "description": "Toasted garlic bread from the restaurant menu",
    "image": "assets/products/cheese-garlic-bread.webp",
    "sizes": [
      [
        "Standard",
        90
      ]
    ],
    "ingredients": "Toasted garlic bread from the restaurant menu",
    "portion": "",
    "source": "menu-poster"
  },
  {
    "id": "makkhani-cheese-garlic-bread",
    "name": "Makkhani Cheese Garlic Bread",
    "category": "garlic-bread",
    "type": "garlic-bread",
    "tag": "Garlic Bread",
    "tone": "",
    "description": "Toasted garlic bread from the restaurant menu",
    "image": "assets/products/makkhani-cheese-garlic-bread.webp",
    "sizes": [
      [
        "Standard",
        100
      ]
    ],
    "ingredients": "Toasted garlic bread from the restaurant menu",
    "portion": "",
    "source": "menu-poster"
  },
  {
    "id": "salted-fries",
    "name": "Salted Fries",
    "category": "fries",
    "type": "fries",
    "tag": "Fries",
    "tone": "",
    "description": "Fries prepared with the listed flavour",
    "image": "assets/products/salted-fries.webp",
    "sizes": [
      [
        "Standard",
        50
      ]
    ],
    "ingredients": "Fries prepared with the listed flavour",
    "portion": "",
    "source": "menu-poster"
  },
  {
    "id": "peri-peri-fries",
    "name": "Peri Peri Fries",
    "category": "fries",
    "type": "fries",
    "tag": "Fries",
    "tone": "",
    "description": "Fries prepared with the listed flavour",
    "image": "assets/products/peri-peri-fries.webp",
    "sizes": [
      [
        "Standard",
        70
      ]
    ],
    "ingredients": "Fries prepared with the listed flavour",
    "portion": "",
    "source": "menu-poster"
  },
  {
    "id": "cheese-pizza-fries",
    "name": "Cheese Pizza Fries",
    "category": "fries",
    "type": "fries",
    "tag": "Fries",
    "tone": "",
    "description": "Fries prepared with the listed flavour",
    "image": "assets/products/cheese-pizza-fries.webp",
    "sizes": [
      [
        "Standard",
        90
      ]
    ],
    "ingredients": "Fries prepared with the listed flavour",
    "portion": "",
    "source": "menu-poster"
  },
  {
    "id": "red-sauce-pasta",
    "name": "Red Sauce Pasta",
    "category": "pasta",
    "type": "pasta",
    "tag": "Pasta",
    "tone": "",
    "description": "Pasta with red sauce flavour",
    "image": "assets/products/red-sauce-pasta.webp",
    "sizes": [
      [
        "Standard",
        70
      ]
    ],
    "ingredients": "Pasta with red sauce flavour",
    "portion": "",
    "source": "menu-poster"
  },
  {
    "id": "white-sauce-pasta",
    "name": "White Sauce Pasta",
    "category": "pasta",
    "type": "pasta",
    "tag": "Pasta",
    "tone": "",
    "description": "Pasta with white sauce flavour",
    "image": "assets/products/white-sauce-pasta.webp",
    "sizes": [
      [
        "Standard",
        70
      ]
    ],
    "ingredients": "Pasta with white sauce flavour",
    "portion": "",
    "source": "menu-poster"
  },
  {
    "id": "tandoori-sauce-pasta",
    "name": "Tandoori Sauce Pasta",
    "category": "pasta",
    "type": "pasta",
    "tag": "Pasta",
    "tone": "",
    "description": "Pasta with tandoori sauce flavour",
    "image": "assets/products/tandoori-sauce-pasta.webp",
    "sizes": [
      [
        "Standard",
        90
      ]
    ],
    "ingredients": "Pasta with tandoori sauce flavour",
    "portion": "",
    "source": "menu-poster"
  },
  {
    "id": "makkhani-sauce-pasta",
    "name": "Makkhani Sauce Pasta",
    "category": "pasta",
    "type": "pasta",
    "tag": "Pasta",
    "tone": "",
    "description": "Pasta with makkhani sauce flavour",
    "image": "assets/products/makkhani-sauce-pasta.webp",
    "sizes": [
      [
        "Standard",
        100
      ]
    ],
    "ingredients": "Pasta with makkhani sauce flavour",
    "portion": "",
    "source": "menu-poster"
  },
  {
    "id": "mix-pasta",
    "name": "Mix Pasta",
    "category": "pasta",
    "type": "pasta",
    "tag": "Pasta",
    "tone": "",
    "description": "Pasta with mix flavour",
    "image": "assets/products/mix-pasta.webp",
    "sizes": [
      [
        "Standard",
        100
      ]
    ],
    "ingredients": "Pasta with mix flavour",
    "portion": "",
    "source": "menu-poster"
  },
  {
    "id": "classic-pasta",
    "name": "Classic Pasta",
    "category": "pasta",
    "type": "pasta",
    "tag": "Special price",
    "tone": "",
    "description": "Special pasta price supplied separately by the restaurant",
    "image": "assets/products/classic-pasta.webp",
    "sizes": [
      [
        "Standard",
        89
      ]
    ],
    "ingredients": "Special pasta price supplied separately by the restaurant",
    "portion": "",
    "source": "menu-poster"
  },
  {
    "id": "simple-noodles",
    "name": "Simple Noodles",
    "category": "chinese",
    "type": "chinese",
    "tag": "Chinese",
    "tone": "",
    "description": "Chinese Corner item from the restaurant menu",
    "image": "assets/products/simple-noodles.webp",
    "sizes": [
      [
        "Standard",
        70
      ]
    ],
    "ingredients": "Chinese Corner item from the restaurant menu",
    "portion": "",
    "source": "menu-poster"
  },
  {
    "id": "hakka-noodles",
    "name": "Hakka Noodles",
    "category": "chinese",
    "type": "chinese",
    "tag": "Chinese",
    "tone": "",
    "description": "Chinese Corner item from the restaurant menu",
    "image": "assets/products/hakka-noodles.webp",
    "sizes": [
      [
        "Standard",
        80
      ]
    ],
    "ingredients": "Chinese Corner item from the restaurant menu",
    "portion": "",
    "source": "menu-poster"
  },
  {
    "id": "french-noodles",
    "name": "French Noodles",
    "category": "chinese",
    "type": "chinese",
    "tag": "Chinese",
    "tone": "",
    "description": "Chinese Corner item from the restaurant menu",
    "image": "assets/products/french-noodles.webp",
    "sizes": [
      [
        "Standard",
        60
      ]
    ],
    "ingredients": "Chinese Corner item from the restaurant menu",
    "portion": "",
    "source": "menu-poster"
  },
  {
    "id": "chilli-potato",
    "name": "Chilli Potato",
    "category": "chinese",
    "type": "chinese",
    "tag": "Chinese",
    "tone": "",
    "description": "Chinese Corner item from the restaurant menu",
    "image": "assets/products/chilli-potato.webp",
    "sizes": [
      [
        "Standard",
        119
      ]
    ],
    "ingredients": "Chinese Corner item from the restaurant menu",
    "portion": "",
    "source": "menu-poster"
  },
  {
    "id": "chilli-paneer",
    "name": "Chilli Paneer",
    "category": "chinese",
    "type": "chinese",
    "tag": "Chinese",
    "tone": "",
    "description": "Chinese Corner item from the restaurant menu",
    "image": "assets/products/chilli-paneer.webp",
    "sizes": [
      [
        "Standard",
        130
      ]
    ],
    "ingredients": "Chinese Corner item from the restaurant menu",
    "portion": "",
    "source": "menu-poster"
  },
  {
    "id": "veg-spring-roll",
    "name": "Veg Spring Roll",
    "category": "chinese",
    "type": "chinese",
    "tag": "Chinese",
    "tone": "",
    "description": "Chinese Corner item from the restaurant menu",
    "image": "assets/products/veg-spring-roll.webp",
    "sizes": [
      [
        "Standard",
        60
      ]
    ],
    "ingredients": "Chinese Corner item from the restaurant menu",
    "portion": "",
    "source": "menu-poster"
  },
  {
    "id": "paneer-spring-roll",
    "name": "Paneer Spring Roll",
    "category": "chinese",
    "type": "chinese",
    "tag": "Chinese",
    "tone": "",
    "description": "Chinese Corner item from the restaurant menu",
    "image": "assets/products/paneer-spring-roll.webp",
    "sizes": [
      [
        "Standard",
        100
      ]
    ],
    "ingredients": "Chinese Corner item from the restaurant menu",
    "portion": "",
    "source": "menu-poster"
  },
  {
    "id": "veg-chowmein",
    "name": "Veg Chowmein",
    "category": "chinese",
    "type": "chinese",
    "tag": "Chinese",
    "tone": "",
    "description": "Chinese Corner item from the restaurant menu",
    "image": "assets/products/veg-chowmein.webp",
    "sizes": [
      [
        "Standard",
        60
      ]
    ],
    "ingredients": "Chinese Corner item from the restaurant menu",
    "portion": "",
    "source": "menu-poster"
  },
  {
    "id": "paneer-chowmein",
    "name": "Paneer Chowmein",
    "category": "chinese",
    "type": "chinese",
    "tag": "Chinese",
    "tone": "",
    "description": "Chinese Corner item from the restaurant menu",
    "image": "assets/products/paneer-chowmein.webp",
    "sizes": [
      [
        "Standard",
        80
      ]
    ],
    "ingredients": "Chinese Corner item from the restaurant menu",
    "portion": "",
    "source": "menu-poster"
  },
  {
    "id": "momos-poster-listing",
    "name": "Momos (Poster Listing)",
    "category": "momos",
    "type": "momos",
    "tag": "Poster listing",
    "tone": "gold",
    "description": "Generic momos entry from the menu poster; style and portion should be confirmed with restaurant",
    "image": "assets/products/momos-poster-listing.webp",
    "sizes": [
      [
        "Standard",
        50
      ]
    ],
    "ingredients": "Generic momos entry from the menu poster; style and portion should be confirmed with restaurant",
    "portion": "",
    "source": "menu-poster"
  },
  {
    "id": "steam-momos",
    "name": "Steam Momos",
    "category": "momos",
    "type": "momos",
    "tag": "12 pieces",
    "tone": "gold",
    "description": "Steamed momos",
    "image": "assets/products/steam-momos.webp",
    "sizes": [
      [
        "Standard",
        80
      ]
    ],
    "ingredients": "Steamed momos",
    "portion": "12 pcs",
    "source": "menu-poster"
  },
  {
    "id": "fried-momos",
    "name": "Fried Momos",
    "category": "momos",
    "type": "momos",
    "tag": "12 pieces",
    "tone": "gold",
    "description": "Fried momos",
    "image": "assets/products/fried-momos.webp",
    "sizes": [
      [
        "Standard",
        90
      ]
    ],
    "ingredients": "Fried momos",
    "portion": "12 pcs",
    "source": "menu-poster"
  },
  {
    "id": "kurkura-momos",
    "name": "Kurkura Momos",
    "category": "momos",
    "type": "momos",
    "tag": "10 pieces",
    "tone": "gold",
    "description": "Crunchy kurkura momos",
    "image": "assets/products/kurkura-momos.webp",
    "sizes": [
      [
        "Standard",
        119
      ]
    ],
    "ingredients": "Crunchy kurkura momos",
    "portion": "10 pcs",
    "source": "menu-poster"
  },
  {
    "id": "veg-wrap",
    "name": "Veg Wrap",
    "category": "sandwiches",
    "type": "sandwiches",
    "tag": "Fresh bites",
    "tone": "",
    "description": "Wrap or sandwich from the restaurant menu",
    "image": "assets/products/veg-wrap.webp",
    "sizes": [
      [
        "Standard",
        60
      ]
    ],
    "ingredients": "Wrap or sandwich from the restaurant menu",
    "portion": "",
    "source": "menu-poster"
  },
  {
    "id": "paneer-wrap",
    "name": "Paneer Wrap",
    "category": "sandwiches",
    "type": "sandwiches",
    "tag": "Fresh bites",
    "tone": "",
    "description": "Wrap or sandwich from the restaurant menu",
    "image": "assets/products/paneer-wrap.webp",
    "sizes": [
      [
        "Standard",
        80
      ]
    ],
    "ingredients": "Wrap or sandwich from the restaurant menu",
    "portion": "",
    "source": "menu-poster"
  },
  {
    "id": "veg-sandwich",
    "name": "Veg Sandwich",
    "category": "sandwiches",
    "type": "sandwiches",
    "tag": "2 pieces",
    "tone": "",
    "description": "Wrap or sandwich from the restaurant menu",
    "image": "assets/products/veg-sandwich.webp",
    "sizes": [
      [
        "Standard",
        99
      ]
    ],
    "ingredients": "Wrap or sandwich from the restaurant menu",
    "portion": "2 pcs",
    "source": "menu-poster"
  },
  {
    "id": "paneer-sandwich",
    "name": "Paneer Sandwich",
    "category": "sandwiches",
    "type": "sandwiches",
    "tag": "2 pieces",
    "tone": "",
    "description": "Wrap or sandwich from the restaurant menu",
    "image": "assets/products/paneer-sandwich.webp",
    "sizes": [
      [
        "Standard",
        119
      ]
    ],
    "ingredients": "Wrap or sandwich from the restaurant menu",
    "portion": "2 pcs",
    "source": "menu-poster"
  },
  {
    "id": "italian-veg-sandwich",
    "name": "Italian Veg Sandwich",
    "category": "sandwiches",
    "type": "sandwiches",
    "tag": "Fresh bites",
    "tone": "",
    "description": "Wrap or sandwich from the restaurant menu",
    "image": "assets/products/italian-veg-sandwich.webp",
    "sizes": [
      [
        "Standard",
        130
      ]
    ],
    "ingredients": "Wrap or sandwich from the restaurant menu",
    "portion": "",
    "source": "menu-poster"
  },
  {
    "id": "coke",
    "name": "Coke",
    "category": "drinks",
    "type": "drinks",
    "tag": "Drinks",
    "tone": "green",
    "description": "Drink from the restaurant menu",
    "image": "assets/products/coke.webp",
    "sizes": [
      [
        "Standard",
        30
      ]
    ],
    "ingredients": "Drink from the restaurant menu",
    "portion": "",
    "source": "menu-poster"
  },
  {
    "id": "rooh-afza-drink",
    "name": "Rooh Afza Drink",
    "category": "drinks",
    "type": "drinks",
    "tag": "Drinks",
    "tone": "green",
    "description": "Drink from the restaurant menu",
    "image": "assets/products/rooh-afza-drink.webp",
    "sizes": [
      [
        "Standard",
        50
      ]
    ],
    "ingredients": "Drink from the restaurant menu",
    "portion": "",
    "source": "menu-poster"
  },
  {
    "id": "hot-coffee",
    "name": "Hot Coffee",
    "category": "drinks",
    "type": "drinks",
    "tag": "Drinks",
    "tone": "green",
    "description": "Drink from the restaurant menu",
    "image": "assets/products/hot-coffee.webp",
    "sizes": [
      [
        "Standard",
        35
      ]
    ],
    "ingredients": "Drink from the restaurant menu",
    "portion": "",
    "source": "menu-poster"
  },
  {
    "id": "tea",
    "name": "Tea",
    "category": "drinks",
    "type": "drinks",
    "tag": "Drinks",
    "tone": "green",
    "description": "Drink from the restaurant menu",
    "image": "assets/products/tea.webp",
    "sizes": [
      [
        "Standard",
        20
      ]
    ],
    "ingredients": "Drink from the restaurant menu",
    "portion": "",
    "source": "menu-poster"
  },
  {
    "id": "water-bottle",
    "name": "Water Bottle",
    "category": "drinks",
    "type": "drinks",
    "tag": "Drinks",
    "tone": "green",
    "description": "Drink from the restaurant menu",
    "image": "assets/products/water-bottle.webp",
    "sizes": [
      [
        "Standard",
        20
      ]
    ],
    "ingredients": "Drink from the restaurant menu",
    "portion": "",
    "source": "menu-poster"
  },
  {
    "id": "virgin-mojito",
    "name": "Virgin Mojito",
    "category": "mojitos",
    "type": "mojitos",
    "tag": "Mojitos",
    "tone": "green",
    "description": "With lime and mint",
    "image": "assets/products/virgin-mojito.webp",
    "sizes": [
      [
        "Standard",
        75
      ]
    ],
    "ingredients": "With lime and mint",
    "portion": "",
    "source": "menu-poster"
  },
  {
    "id": "coke-mojito",
    "name": "Coke Mojito",
    "category": "mojitos",
    "type": "mojitos",
    "tag": "Mojitos",
    "tone": "green",
    "description": "With Coke, lime and mint",
    "image": "assets/products/coke-mojito.webp",
    "sizes": [
      [
        "Standard",
        75
      ]
    ],
    "ingredients": "With Coke, lime and mint",
    "portion": "",
    "source": "menu-poster"
  },
  {
    "id": "cranberry-mojito",
    "name": "Cranberry Mojito",
    "category": "mojitos",
    "type": "mojitos",
    "tag": "Mojitos",
    "tone": "green",
    "description": "With cranberry and mint",
    "image": "assets/products/cranberry-mojito.webp",
    "sizes": [
      [
        "Standard",
        85
      ]
    ],
    "ingredients": "With cranberry and mint",
    "portion": "",
    "source": "menu-poster"
  },
  {
    "id": "pineapple-mojito",
    "name": "Pineapple Mojito",
    "category": "mojitos",
    "type": "mojitos",
    "tag": "Mojitos",
    "tone": "green",
    "description": "With pineapple juice, lime and mint",
    "image": "assets/products/pineapple-mojito.webp",
    "sizes": [
      [
        "Standard",
        85
      ]
    ],
    "ingredients": "With pineapple juice, lime and mint",
    "portion": "",
    "source": "menu-poster"
  },
  {
    "id": "blue-mojito",
    "name": "Blue Mojito",
    "category": "mojitos",
    "type": "mojitos",
    "tag": "Mojitos",
    "tone": "green",
    "description": "With sweet lime, orange and mint",
    "image": "assets/products/blue-mojito.webp",
    "sizes": [
      [
        "Standard",
        100
      ]
    ],
    "ingredients": "With sweet lime, orange and mint",
    "portion": "",
    "source": "menu-poster"
  },
  {
    "id": "cold-coffee",
    "name": "Cold Coffee",
    "category": "shakes",
    "type": "shakes",
    "tag": "Shakes",
    "tone": "green",
    "description": "Cold shake from the restaurant menu",
    "image": "assets/products/cold-coffee.webp",
    "sizes": [
      [
        "Standard",
        80
      ]
    ],
    "ingredients": "Cold shake from the restaurant menu",
    "portion": "",
    "source": "menu-poster"
  },
  {
    "id": "butterscotch-shake",
    "name": "Butterscotch Shake",
    "category": "shakes",
    "type": "shakes",
    "tag": "Shakes",
    "tone": "green",
    "description": "Cold shake from the restaurant menu",
    "image": "assets/products/butterscotch-shake.webp",
    "sizes": [
      [
        "Standard",
        80
      ]
    ],
    "ingredients": "Cold shake from the restaurant menu",
    "portion": "",
    "source": "menu-poster"
  },
  {
    "id": "strawberry-shake",
    "name": "Strawberry Shake",
    "category": "shakes",
    "type": "shakes",
    "tag": "Shakes",
    "tone": "green",
    "description": "Cold shake from the restaurant menu",
    "image": "assets/products/strawberry-shake.webp",
    "sizes": [
      [
        "Standard",
        80
      ]
    ],
    "ingredients": "Cold shake from the restaurant menu",
    "portion": "",
    "source": "menu-poster"
  },
  {
    "id": "mango-shake",
    "name": "Mango Shake",
    "category": "shakes",
    "type": "shakes",
    "tag": "Shakes",
    "tone": "green",
    "description": "Cold shake from the restaurant menu",
    "image": "assets/products/mango-shake.webp",
    "sizes": [
      [
        "Standard",
        80
      ]
    ],
    "ingredients": "Cold shake from the restaurant menu",
    "portion": "",
    "source": "menu-poster"
  },
  {
    "id": "pineapple-shake",
    "name": "Pineapple Shake",
    "category": "shakes",
    "type": "shakes",
    "tag": "Shakes",
    "tone": "green",
    "description": "Cold shake from the restaurant menu",
    "image": "assets/products/pineapple-shake.webp",
    "sizes": [
      [
        "Standard",
        80
      ]
    ],
    "ingredients": "Cold shake from the restaurant menu",
    "portion": "",
    "source": "menu-poster"
  },
  {
    "id": "vanilla-shake",
    "name": "Vanilla Shake",
    "category": "shakes",
    "type": "shakes",
    "tag": "Shakes",
    "tone": "green",
    "description": "Cold shake from the restaurant menu",
    "image": "assets/products/vanilla-shake.webp",
    "sizes": [
      [
        "Standard",
        80
      ]
    ],
    "ingredients": "Cold shake from the restaurant menu",
    "portion": "",
    "source": "menu-poster"
  },
  {
    "id": "chocolate-shake",
    "name": "Chocolate Shake",
    "category": "shakes",
    "type": "shakes",
    "tag": "Shakes",
    "tone": "green",
    "description": "Cold shake from the restaurant menu",
    "image": "assets/products/chocolate-shake.webp",
    "sizes": [
      [
        "Standard",
        80
      ]
    ],
    "ingredients": "Cold shake from the restaurant menu",
    "portion": "",
    "source": "menu-poster"
  },
  {
    "id": "banana-shake",
    "name": "Banana Shake",
    "category": "shakes",
    "type": "shakes",
    "tag": "Shakes",
    "tone": "green",
    "description": "Cold shake from the restaurant menu",
    "image": "assets/products/banana-shake.webp",
    "sizes": [
      [
        "Standard",
        80
      ]
    ],
    "ingredients": "Cold shake from the restaurant menu",
    "portion": "",
    "source": "menu-poster"
  },
  {
    "id": "kesar-pista-shake",
    "name": "Kesar Pista Shake",
    "category": "shakes",
    "type": "shakes",
    "tag": "Shakes",
    "tone": "green",
    "description": "Cold shake from the restaurant menu",
    "image": "assets/products/kesar-pista-shake.webp",
    "sizes": [
      [
        "Standard",
        80
      ]
    ],
    "ingredients": "Cold shake from the restaurant menu",
    "portion": "",
    "source": "menu-poster"
  },
  {
    "id": "vanilla-ice-cream",
    "name": "Vanilla Ice Cream",
    "category": "desserts",
    "type": "desserts",
    "tag": "Desserts",
    "tone": "",
    "description": "Sweet treat from the restaurant menu",
    "image": "assets/products/vanilla-ice-cream.webp",
    "sizes": [
      [
        "Standard",
        40
      ]
    ],
    "ingredients": "Sweet treat from the restaurant menu",
    "portion": "",
    "source": "menu-poster"
  },
  {
    "id": "butterscotch-ice-cream",
    "name": "Butterscotch Ice Cream",
    "category": "desserts",
    "type": "desserts",
    "tag": "Desserts",
    "tone": "",
    "description": "Sweet treat from the restaurant menu",
    "image": "assets/products/butterscotch-ice-cream.webp",
    "sizes": [
      [
        "Standard",
        40
      ]
    ],
    "ingredients": "Sweet treat from the restaurant menu",
    "portion": "",
    "source": "menu-poster"
  },
  {
    "id": "chocolate-ice-cream",
    "name": "Chocolate Ice Cream",
    "category": "desserts",
    "type": "desserts",
    "tag": "Desserts",
    "tone": "",
    "description": "Sweet treat from the restaurant menu",
    "image": "assets/products/chocolate-ice-cream.webp",
    "sizes": [
      [
        "Standard",
        40
      ]
    ],
    "ingredients": "Sweet treat from the restaurant menu",
    "portion": "",
    "source": "menu-poster"
  },
  {
    "id": "strawberry-ice-cream",
    "name": "Strawberry Ice Cream",
    "category": "desserts",
    "type": "desserts",
    "tag": "Desserts",
    "tone": "",
    "description": "Sweet treat from the restaurant menu",
    "image": "assets/products/strawberry-ice-cream.webp",
    "sizes": [
      [
        "Standard",
        40
      ]
    ],
    "ingredients": "Sweet treat from the restaurant menu",
    "portion": "",
    "source": "menu-poster"
  },
  {
    "id": "milk-ice-cream",
    "name": "Milk Ice Cream",
    "category": "desserts",
    "type": "desserts",
    "tag": "Desserts",
    "tone": "",
    "description": "Sweet treat from the restaurant menu",
    "image": "assets/products/milk-ice-cream.webp",
    "sizes": [
      [
        "Standard",
        40
      ]
    ],
    "ingredients": "Sweet treat from the restaurant menu",
    "portion": "",
    "source": "menu-poster"
  },
  {
    "id": "chocolate-cake",
    "name": "Chocolate Cake",
    "category": "desserts",
    "type": "desserts",
    "tag": "Desserts",
    "tone": "",
    "description": "Sweet treat from the restaurant menu",
    "image": "assets/products/chocolate-cake.webp",
    "sizes": [
      [
        "Standard",
        40
      ]
    ],
    "ingredients": "Sweet treat from the restaurant menu",
    "portion": "",
    "source": "menu-poster"
  },
  {
    "id": "pastries",
    "name": "Pastries",
    "category": "desserts",
    "type": "desserts",
    "tag": "Desserts",
    "tone": "",
    "description": "Sweet treat from the restaurant menu",
    "image": "assets/products/pastries.webp",
    "sizes": [
      [
        "Standard",
        40
      ]
    ],
    "ingredients": "Sweet treat from the restaurant menu",
    "portion": "",
    "source": "menu-poster"
  },
  {
    "id": "choco-lava-cake",
    "name": "Choco Lava Cake",
    "category": "desserts",
    "type": "desserts",
    "tag": "Desserts",
    "tone": "",
    "description": "Sweet treat from the restaurant menu",
    "image": "assets/products/choco-lava-cake.webp",
    "sizes": [
      [
        "Standard",
        60
      ]
    ],
    "ingredients": "Sweet treat from the restaurant menu",
    "portion": "",
    "source": "menu-poster"
  },
  {
    "id": "combo-family-fun",
    "name": "Family Fun Meal",
    "category": "combos",
    "type": "combo",
    "tag": "Family favourite",
    "tone": "gold",
    "description": "Any Medium Pizza • 2 Cokes • Garlic Bread",
    "image": "assets/combos/family-fun.webp",
    "sizes": [
      [
        "Combo",
        450
      ]
    ],
    "ingredients": "Any Medium Pizza, 2 Cokes and Garlic Bread.",
    "portion": "",
    "source": "combo-poster",
    "comboOptions": [
      {
        "value": "margherita",
        "label": "Margherita"
      },
      {
        "value": "cheese-paneer",
        "label": "Cheese Paneer"
      },
      {
        "value": "cheese-tomato",
        "label": "Cheese Tomato"
      },
      {
        "value": "delight-special",
        "label": "Delight Special"
      },
      {
        "value": "fresh-veggie",
        "label": "Fresh Veggie"
      },
      {
        "value": "hungry-special",
        "label": "Hungry Special"
      },
      {
        "value": "mexican-veggie",
        "label": "Mexican Veggie"
      },
      {
        "value": "farm-house",
        "label": "Farm House"
      },
      {
        "value": "teekha-paneer",
        "label": "Teekha Paneer"
      },
      {
        "value": "shikarpur-lover",
        "label": "Shikarpur Lover"
      },
      {
        "value": "deluxe-veggie",
        "label": "Deluxe Veggie"
      },
      {
        "value": "five-pepper",
        "label": "Five Pepper"
      },
      {
        "value": "spicy-paneer",
        "label": "Spicy Paneer"
      },
      {
        "value": "makhkhani-paneer",
        "label": "Makhkhani Paneer"
      },
      {
        "value": "achari-pizza",
        "label": "Achari Pizza"
      },
      {
        "value": "veg-supreme",
        "label": "Veg Supreme"
      },
      {
        "value": "king-9-wonder",
        "label": "King 9 Wonder"
      },
      {
        "value": "pizza-pasta",
        "label": "Pizza Pasta"
      },
      {
        "value": "tandoori-special",
        "label": "Tandoori Special"
      },
      {
        "value": "kulhad-pizza",
        "label": "Kulhad Pizza"
      }
    ],
    "comboPrompt": "Choose your Medium pizza",
    "comboChoiceSize": "Medium",
    "startingPrice": false,
    "comboNote": "Choose your medium pizza. Final preparation and delivery details will be confirmed on callback.",
    "comboItems": [
      "Any Medium Pizza",
      "2 Cokes",
      "Garlic Bread"
    ]
  },
  {
    "id": "combo-student-special",
    "name": "Student Special Meal",
    "category": "combos",
    "type": "combo",
    "tag": "Student deal",
    "tone": "gold",
    "description": "Delights Spl. Pizza • 2 Cokes • 2 Cheese Burgers",
    "image": "assets/combos/student-special.webp",
    "sizes": [
      [
        "Combo",
        270
      ]
    ],
    "ingredients": "Delights Special Pizza, 2 Cokes and 2 Cheese Burgers.",
    "portion": "",
    "source": "combo-poster",
    "comboOptions": [],
    "comboPrompt": "",
    "comboChoiceSize": "",
    "startingPrice": false,
    "comboNote": "Combo contents are fixed as shown in the poster. Final preparation details will be confirmed on callback.",
    "comboItems": [
      "Delights Spl. Pizza",
      "2 Cokes",
      "2 Cheese Burgers"
    ]
  },
  {
    "id": "combo-party-meal",
    "name": "Meal for Party",
    "category": "combos",
    "type": "combo",
    "tag": "Share with friends",
    "tone": "gold",
    "description": "Any Large Pizza • 4 Cokes • 4 Cheese Burgers • 2 Garlic Breads",
    "image": "assets/combos/party-meal.webp",
    "sizes": [
      [
        "Combo",
        850
      ]
    ],
    "ingredients": "Any Large Pizza, 4 Cokes, 4 Cheese Burgers and 2 Garlic Breads.",
    "portion": "",
    "source": "combo-poster",
    "comboOptions": [
      {
        "value": "margherita",
        "label": "Margherita"
      },
      {
        "value": "cheese-paneer",
        "label": "Cheese Paneer"
      },
      {
        "value": "cheese-tomato",
        "label": "Cheese Tomato"
      },
      {
        "value": "delight-special",
        "label": "Delight Special"
      },
      {
        "value": "fresh-veggie",
        "label": "Fresh Veggie"
      },
      {
        "value": "hungry-special",
        "label": "Hungry Special"
      },
      {
        "value": "mexican-veggie",
        "label": "Mexican Veggie"
      },
      {
        "value": "farm-house",
        "label": "Farm House"
      },
      {
        "value": "teekha-paneer",
        "label": "Teekha Paneer"
      },
      {
        "value": "shikarpur-lover",
        "label": "Shikarpur Lover"
      },
      {
        "value": "deluxe-veggie",
        "label": "Deluxe Veggie"
      },
      {
        "value": "five-pepper",
        "label": "Five Pepper"
      },
      {
        "value": "spicy-paneer",
        "label": "Spicy Paneer"
      },
      {
        "value": "makhkhani-paneer",
        "label": "Makhkhani Paneer"
      },
      {
        "value": "achari-pizza",
        "label": "Achari Pizza"
      },
      {
        "value": "veg-supreme",
        "label": "Veg Supreme"
      },
      {
        "value": "king-9-wonder",
        "label": "King 9 Wonder"
      },
      {
        "value": "pizza-pasta",
        "label": "Pizza Pasta"
      },
      {
        "value": "tandoori-special",
        "label": "Tandoori Special"
      },
      {
        "value": "kulhad-pizza",
        "label": "Kulhad Pizza"
      }
    ],
    "comboPrompt": "Choose your Large pizza",
    "comboChoiceSize": "Large",
    "startingPrice": false,
    "comboNote": "Choose your large pizza. Delivery availability and final bill will be confirmed on callback.",
    "comboItems": [
      "Any Large Pizza",
      "4 Cokes",
      "4 Cheese Burgers",
      "2 Garlic Breads"
    ]
  },
  {
    "id": "combo-single-topping",
    "name": "Single Topping Pizza",
    "category": "combos",
    "type": "combo",
    "tag": "Starts at ₹80",
    "tone": "green",
    "description": "Single Topping Pizza — choose your preferred topping option.",
    "image": "assets/combos/single-topping.webp",
    "sizes": [
      [
        "Starting price",
        80
      ]
    ],
    "ingredients": "Single topping pizza. Exact size and final total are confirmed on callback.",
    "portion": "",
    "source": "combo-poster",
    "comboOptions": [
      {
        "value": "onion",
        "label": "1. Onion"
      },
      {
        "value": "capsicum",
        "label": "2. Capsicum"
      },
      {
        "value": "tomato",
        "label": "3. Tomato"
      },
      {
        "value": "corn",
        "label": "4. Corn"
      }
    ],
    "comboPrompt": "Choose one topping",
    "comboChoiceSize": "",
    "startingPrice": true,
    "comboNote": "₹80 is a starting price. Exact pizza size and final total will be confirmed on callback.",
    "comboItems": [
      "Onion",
      "Capsicum",
      "Tomato",
      "Corn"
    ]
  },
  {
    "id": "combo-veg-single",
    "name": "Fun Meal Veg Single Combo",
    "category": "combos",
    "type": "combo",
    "tag": "Starts at ₹290",
    "tone": "green",
    "description": "Fun Meal Veg Single Combo — choose one topping option.",
    "image": "assets/combos/veg-single.webp",
    "sizes": [
      [
        "Starting price",
        290
      ]
    ],
    "ingredients": "Choose one topping option from Onion, Capsicum, Tomato or Corn. Final size and total are confirmed on callback.",
    "portion": "",
    "source": "combo-poster",
    "comboOptions": [
      {
        "value": "onion",
        "label": "1. Onion"
      },
      {
        "value": "capsicum",
        "label": "2. Capsicum"
      },
      {
        "value": "tomato",
        "label": "3. Tomato"
      },
      {
        "value": "corn",
        "label": "4. Corn"
      }
    ],
    "comboPrompt": "Choose one topping option",
    "comboChoiceSize": "",
    "startingPrice": true,
    "comboNote": "₹290 is a starting price. Exact pizza size and final total will be confirmed on callback.",
    "comboItems": [
      "Onion",
      "Capsicum",
      "Tomato",
      "Corn"
    ]
  },
  {
    "id": "combo-veg-double",
    "name": "Fun Meal Veg Double Combo",
    "category": "combos",
    "type": "combo",
    "tag": "Starts at ₹380",
    "tone": "green",
    "description": "Fun Meal Veg Double Combo — choose your two-topping combination.",
    "image": "assets/combos/veg-double.webp",
    "sizes": [
      [
        "Starting price",
        380
      ]
    ],
    "ingredients": "Choose one double-topping combination from the official poster. Final size and total are confirmed on callback.",
    "portion": "",
    "source": "combo-poster",
    "comboOptions": [
      {
        "value": "onion-capsicum",
        "label": "1. Onion + Capsicum"
      },
      {
        "value": "capsicum-tomato",
        "label": "2. Capsicum + Tomato"
      },
      {
        "value": "tomato-red-pepper",
        "label": "3. Tomato + Red Pepper"
      },
      {
        "value": "corn-onion",
        "label": "4. Corn + Onion"
      }
    ],
    "comboPrompt": "Choose a two-topping combination",
    "comboChoiceSize": "",
    "startingPrice": true,
    "comboNote": "₹380 is a starting price. Exact pizza size and final total will be confirmed on callback.",
    "comboItems": [
      "Onion + Capsicum",
      "Capsicum + Tomato",
      "Tomato + Red Pepper",
      "Corn + Onion"
    ]
  }
];
