/* King Pizza Makers Motion Studio: progressive, accessible, state-aware enhancements */
(() => {
  'use strict';
  const reduced = window.matchMedia('(prefers-reduced-motion: reduce)');
  const storageKey = 'kpm_motion_enabled_v1';
  let preference = null;
  try { preference = localStorage.getItem(storageKey); } catch(_) { /* Private browsing safe */ }
  let enabled = !reduced.matches && preference !== 'off';
  const html = document.documentElement;
  const main = document.getElementById('kpm-spa-main');
  if (!main) return;
  const toggle = document.getElementById('kpm-motion-toggle');
  let observer = null;
  let scanFrame = 0;
  let progressFrame = 0;
  let activeTilt = null;
  const revealSelector = [
    '.section-intro','.section-intro-art','.menu-subhead','.menu-controls',
    '.product-card','.royal-combo-card','.taste-tile','.photo-showcase-grid figure',
    '.highlights-row > div','.quick-contact-inner > a','.story-copy',
    '.review-form','.review-panel','.callback-policy-inner > div',
    '.connect-card','.connect-panel','.inner-hero-layout > *',
    '.combo-intro-wrap > *','.combo-policy','.faq-grid > *',
    '.feature-card','.specials-grid > *','.combo-grid > *',
    '.promo-cards > *','.combo-photos > *','.offer-card'
  ].join(',');

  function updateToggle(){
    if(!toggle) return;
    toggle.disabled = reduced.matches;
    const text = reduced.matches ? 'Motion off · system' : (enabled ? 'Motion on' : 'Motion off');
    toggle.querySelector('.motion-label').textContent = text;
    toggle.setAttribute('aria-label', reduced.matches ? 'Animation disabled by your system reduced motion setting' : (enabled ? 'Disable website animations' : 'Enable website animations'));
    toggle.setAttribute('aria-pressed', String(enabled && !reduced.matches));
    toggle.title = reduced.matches ? 'Reduced motion is enabled in your device settings' : 'Toggle animated effects';
  }
  function revealAll(){
    if(observer){observer.disconnect();observer=null;}
    main.querySelectorAll('.kpm-reveal').forEach(el=>el.classList.add('is-visible'));
  }
  function setupObserver(){
    if(!enabled || reduced.matches || !('IntersectionObserver' in window)){revealAll();return;}
    if(observer) observer.disconnect();
    observer = new IntersectionObserver(entries=>{
      for(const entry of entries){
        if(entry.isIntersecting){
          entry.target.classList.add('is-visible');
          observer.unobserve(entry.target);
        }
      }
    },{rootMargin:'0px 0px -28px 0px',threshold:.06});
    main.querySelectorAll('.kpm-reveal:not(.is-visible)').forEach(el=>observer.observe(el));
  }
  function scan(){
    scanFrame=0;
    if(!enabled || reduced.matches){revealAll();return;}
    const matches = main.querySelectorAll(revealSelector);
    let i=0;
    for(const el of matches){
      if(el.classList.contains('kpm-reveal')) continue;
      el.classList.add('kpm-reveal');
      el.style.setProperty('--kpm-delay',`${Math.min(i%4,3)*55}ms`);
      i++;
    }
    setupObserver();
  }
  function queueScan(){ if(!scanFrame)scanFrame=requestAnimationFrame(scan); }
  function buildSparks(){
    const hero = main.querySelector('.hero');
    if(!hero || hero.querySelector('.kpm-spark-field')) return;
    const field=document.createElement('div');field.className='kpm-spark-field';field.setAttribute('aria-hidden','true');
    const particles=[
      [8,26,13,'#ffca59',6.2,-2.3],[18,73,9,'#fa8826',7.8,-.7],[41,17,12,'#faba3f',8,-4.1],
      [65,10,15,'#ffd674',6.8,-2.2],[79,67,10,'#ff7535',7.1,-5.4],[90,23,13,'#ffc33f',9,-.8],
      [96,81,9,'#ffdb83',7.6,-6],[52,75,10,'#fb9931',8.4,-2.6]
    ];
    for(const [x,y,s,col,d,offset] of particles){
      const star=document.createElement('span'); star.className='kpm-spark';star.textContent='✦';
      star.style.cssText=`--sx:${x}%;--sy:${y}%;--ss:${s}px;--sc:${col};--sd:${d}s;--so:${offset}s`;
      field.appendChild(star);
    }
    hero.appendChild(field);
  }
  function updateProgress(){
    progressFrame=0;
    const progress=document.getElementById('kpm-scroll-progress');
    if(!progress || !enabled) return;
    const height=Math.max(1,document.documentElement.scrollHeight-window.innerHeight);
    progress.style.transform=`scaleX(${Math.max(0,Math.min(1,window.scrollY/height))})`;
  }
  function progressOnScroll(){ if(!progressFrame) progressFrame=requestAnimationFrame(updateProgress); }
  function refresh(){
    html.classList.toggle('kpm-motion-on',enabled&&!reduced.matches);
    updateToggle();
    if(!enabled || reduced.matches)revealAll();
    else {buildSparks();queueScan();progressOnScroll();}
  }
  toggle?.addEventListener('click',()=>{
    if(reduced.matches) return;
    enabled=!enabled;
    try {localStorage.setItem(storageKey,enabled?'on':'off')} catch(_){}
    if(enabled){main.querySelectorAll('.kpm-reveal').forEach(el=>el.classList.remove('is-visible'));}
    refresh();
  });
  reduced.addEventListener?.('change',()=>{if(reduced.matches)enabled=false;else enabled=preference!=='off';refresh();});

  // Rebind to the new view as the hash-router swaps its template.
  const mutationObserver=new MutationObserver(mutations=>{
    if(!enabled || reduced.matches)return;
    if(mutations.some(m=>m.addedNodes.length)) {
      buildSparks();queueScan();
    }
  });
  mutationObserver.observe(main,{childList:true,subtree:true});
  const footer=document.querySelector('.footer');
  const cartCount=document.getElementById('cart-count');
  const mobileCartCount=document.getElementById('mobile-cart-count');
  function popCart(el){
    if(!enabled||reduced.matches||!el)return;
    el.classList.remove('kpm-cart-pop');
    void el.offsetWidth;
    el.classList.add('kpm-cart-pop');
  }
  [cartCount,mobileCartCount].forEach(el=>{
    if(!el) return;
    new MutationObserver(()=>popCart(el)).observe(el,{childList:true,characterData:true,subtree:true});
  });
  // Touch ripple works without interfering with event delegation or SPA links.
  document.addEventListener('pointerdown',ev=>{
    if(!enabled || reduced.matches || ev.button!==0)return;
    const target=ev.target.closest('.btn,.cart-button,.quick-add,.category-pill,.qc-order');
    if(!target||target.disabled) return;
    const r=target.getBoundingClientRect();
    if(!r.width || !r.height)return;
    const span=document.createElement('span');span.className='kpm-ripple';
    span.style.left=`${ev.clientX-r.left}px`;span.style.top=`${ev.clientY-r.top}px`;
    target.appendChild(span);
    span.addEventListener('animationend',()=>span.remove(),{once:true});
  },{passive:true});
  // GPU-friendly 3D perspective for fine pointer devices, only the hovered card.
  const finePointer=window.matchMedia('(hover:hover) and (pointer:fine)');
  document.addEventListener('pointermove',ev=>{
    if(!enabled||!finePointer.matches||reduced.matches)return;
    const card=ev.target.closest('.product-card,.royal-combo-card');
    if(!card){if(activeTilt){activeTilt.style.removeProperty('--kpm-tilt-x');activeTilt.style.removeProperty('--kpm-tilt-y');activeTilt=null;}return;}
    if(card!==activeTilt && activeTilt){activeTilt.style.removeProperty('--kpm-tilt-x');activeTilt.style.removeProperty('--kpm-tilt-y');}
    activeTilt=card;
    const rect=card.getBoundingClientRect();
    const px=(ev.clientX-rect.left)/rect.width-.5;
    const py=(ev.clientY-rect.top)/rect.height-.5;
    card.style.setProperty('--kpm-tilt-x',`${(px*3.8).toFixed(2)}deg`);
    card.style.setProperty('--kpm-tilt-y',`${(-py*3.8).toFixed(2)}deg`);
  },{passive:true});
  document.addEventListener('pointerout',ev=>{
    if(activeTilt && !ev.relatedTarget?.closest?.('.product-card,.royal-combo-card')){
      activeTilt.style.removeProperty('--kpm-tilt-x');activeTilt.style.removeProperty('--kpm-tilt-y');activeTilt=null;
    }
  },{passive:true});
  // Tiny celebratory particles on add-to-basket, not an intrusive large animation.
  document.addEventListener('click',ev=>{
    if(!enabled||reduced.matches||!ev.target.closest('#add-to-cart'))return;
    const rect=ev.target.closest('#add-to-cart').getBoundingClientRect();
    const cx=rect.left+rect.width/2, cy=rect.top+rect.height/2;
    for(let i=0;i<7;i++){
      const particle=document.createElement('span');particle.className='kpm-order-spark';particle.textContent=i%2?'✦':'✧';
      const angle=(Math.PI*2*i/7);
      particle.style.cssText=`left:${cx}px;top:${cy}px;--burst-x:${Math.cos(angle)*68}px;--burst-y:${Math.sin(angle)*55}px`;
      document.body.appendChild(particle);
      particle.addEventListener('animationend',()=>particle.remove(),{once:true});
    }
  });
  window.addEventListener('scroll',progressOnScroll,{passive:true});
  window.addEventListener('resize',progressOnScroll,{passive:true});
  window.addEventListener('hashchange',()=>{buildSparks();queueScan();progressOnScroll();});
  refresh();
})();
