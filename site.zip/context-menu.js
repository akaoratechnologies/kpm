/* King Pizza Makers: custom site context menu.
 * Intercepts browser page right-clicks; editable fields preserve keyboard
 * input shortcuts and have native-safe custom selection actions.
 * Browsers/OS can still show their own menus in privileged situations.
 */
(() => {
  'use strict';
  const title = 'King Pizza Makers';
  const defaultWhatsApp = 'https://wa.me/919759495433?text=' + encodeURIComponent('Hi King Pizza Makers, I would like to enquire about ordering.');
  const menu = document.createElement('div');
  menu.id = 'kpm-context-menu';
  menu.className = 'kpm-context-menu';
  menu.setAttribute('role', 'menu');
  menu.setAttribute('aria-label', 'King Pizza Makers quick actions');
  menu.setAttribute('aria-hidden', 'true');
  menu.setAttribute('tabindex', '-1');
  menu.hidden = true;
  document.body.appendChild(menu);

  let previousFocus = null;
  let context = {link: null, image: null, editable: null, product: null};
  const icon = (name) => {
    const paths = {
      home: '<path d="m3 10 9-7 9 7"/><path d="M5 9v12h14V9"/><path d="M9 21v-8h6v8"/>',
      menu: '<path d="M3 4h18M3 10h18M3 16h18M3 22h18"/>',
      basket: '<path d="M5 8h14l-1.6 12H6.6L5 8Z"/><path d="M9 9V6a3 3 0 0 1 6 0v3"/>',
      call: '<path d="M22 16.9v3a2 2 0 0 1-2.2 2A19 19 0 0 1 2.1 4.2 2 2 0 0 1 4.1 2h3a2 2 0 0 1 2 1.7l.6 2.8a2 2 0 0 1-.6 1.9L7 10a16 16 0 0 0 7 7l1.6-2.1a2 2 0 0 1 1.9-.6l2.8.6A2 2 0 0 1 22 16.9Z"/>',
      map: '<path d="M20 10c0 5-8 12-8 12S4 15 4 10a8 8 0 1 1 16 0Z"/><circle cx="12" cy="10" r="2.5"/>',
      instagram: '<rect x="2" y="2" width="20" height="20" rx="6"/><circle cx="12" cy="12" r="4.5"/><path d="M18 6h.01"/>',
      chat: '<path d="M21 11.5a8.4 8.4 0 0 1-8.9 8.4 9 9 0 0 1-4-.9L3 21l1.9-5.1a8.8 8.8 0 0 1-.9-4.1A8.5 8.5 0 1 1 21 11.5Z"/><path d="m9 10 2 2 4-4"/>',
      copy: '<rect x="8" y="8" width="13" height="13" rx="2"/><path d="M16 8V5a2 2 0 0 0-2-2H5a2 2 0 0 0-2 2v9a2 2 0 0 0 2 2h3"/>',
      external: '<path d="M14 3h7v7M21 3l-10 10"/><path d="M21 13v7a1 1 0 0 1-1 1H4a1 1 0 0 1-1-1V4a1 1 0 0 1 1-1h7"/>',
      product: '<rect x="3" y="3" width="18" height="18" rx="3"/><path d="M3 9h18M9 3v18"/>',
      image: '<rect x="3" y="3" width="18" height="18" rx="2"/><circle cx="8" cy="8" r="1"/><path d="m21 15-5-5L5 21"/>',
      select: '<path d="M4 7V4h3M17 4h3v3M20 17v3h-3M7 20H4v-3"/><path d="M8 10h8M8 14h8"/>',
      paste: '<rect x="6" y="5" width="14" height="17" rx="2"/><path d="M10 5V3h6v2M9 11h8M9 15h8"/>',
      arrow: '<path d="M5 12h14m-6-6 6 6-6 6"/>'
    };
    return '<svg width="17" height="17" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true">' + paths[name] + '</svg>';
  };
  const note = (message) => {
    if (typeof window.showToast === 'function') { window.showToast(message); return; }
    const toast = document.querySelector('#toast');
    if (toast) { toast.textContent = message; toast.classList.add('show'); setTimeout(() => toast.classList.remove('show'), 2500); }
  };
  const isEditable = element => Boolean(element && (element.matches('input:not([type=checkbox]):not([type=radio]):not([type=button]):not([type=submit]), textarea, [contenteditable="true"]') || element.closest('[contenteditable="true"]')));
  const isSafeWebUrl = url => {
    try { return ['http:', 'https:', 'file:'].includes(new URL(url, document.baseURI).protocol); }
    catch { return false; }
  };
  const item = (action, label, name, secondary = '') =>
    `<button class="kpm-cm-item" type="button" role="menuitem" data-kpm-action="${action}">${icon(name)}<span class="kpm-cm-label">${label}</span>${secondary ? `<span class="kpm-cm-side">${secondary}</span>` : ''}</button>`;
  const divider = '<div class="kpm-cm-divider" role="separator"></div>';

  function getContext(target) {
    const editable = target.closest('input, textarea, [contenteditable="true"]');
    const link = target.closest('a[href]');
    const card = target.closest('.product-card');
    const product = card?.querySelector('a[href*="#/product?id="]') || (link?.matches('a[href*="#/product?id="]') ? link : null);
    const image = target.closest('img[src]');
    return {editable: isEditable(editable) ? editable : null, link, product, image};
  }

  function openAt(x, y, target, viaKeyboard = false) {
    context = getContext(target);
    previousFocus = document.activeElement;
    const contextual = [];
    if (context.editable) {
      contextual.push(item('select-all', 'Select all in field', 'select'));
      contextual.push(item('copy-selection', 'Copy selected text', 'copy'));
      if (navigator.clipboard?.readText && window.isSecureContext) contextual.push(item('paste', 'Paste from clipboard', 'paste'));
      contextual.push(divider);
    } else {
      if (context.product) contextual.push(item('view-product', 'View product details', 'product'));
      if (context.link && isSafeWebUrl(context.link.href)) {
        contextual.push(item('open-link', 'Open link in new tab', 'external'));
        contextual.push(item('copy-link', 'Copy link address', 'copy'));
      } else if (context.image && isSafeWebUrl(context.image.src)) {
        contextual.push(item('open-image', 'View full image', 'image'));
        contextual.push(item('copy-image-link', 'Copy image address', 'copy'));
      }
      if (contextual.length) contextual.push(divider);
    }
    menu.innerHTML = `<div class="kpm-cm-header"><span class="kpm-cm-crown" aria-hidden="true">♛</span><span><strong>${title}</strong><small>QUICK ACTIONS</small></span><span class="kpm-cm-dot" aria-hidden="true"></span></div>` +
      contextual.join('') +
      item('home', 'Home', 'home') +
      item('full-menu', 'Explore full menu', 'menu') +
      item('basket', 'My basket', 'basket') + divider +
      item('whatsapp', 'WhatsApp enquiry', 'chat') +
      item('call', 'Call restaurant', 'call') +
      item('maps', 'Google Maps location', 'map') +
      item('copy-page', 'Copy page link', 'copy') +
      `<div class="kpm-cm-footer">KING PIZZA MAKERS <span>·</span> SHIKARPUR</div>`;
    menu.hidden = false;
    menu.setAttribute('aria-hidden', 'false');
    const bounds = menu.getBoundingClientRect();
    const pad = 10;
    const px = Math.max(pad, Math.min(x, window.innerWidth - bounds.width - pad));
    const py = Math.max(pad, Math.min(y, window.innerHeight - bounds.height - pad));
    menu.style.left = `${px}px`;
    menu.style.top = `${py}px`;
    if (viaKeyboard) menu.querySelector('[role="menuitem"]')?.focus();
  }
  function closeMenu(restoreFocus = false) {
    if (menu.hidden) return;
    menu.hidden = true;
    menu.setAttribute('aria-hidden', 'true');
    if (restoreFocus && previousFocus?.isConnected) previousFocus.focus({preventScroll:true});
  }
  async function copyValue(value) {
    if (!value) { note('Nothing selected to copy'); return; }
    try {
      if (navigator.clipboard?.writeText && window.isSecureContext) await navigator.clipboard.writeText(value);
      else {
        const field = document.createElement('textarea');
        field.value = value;
        field.style.cssText = 'position:fixed;left:-9999px;top:0;opacity:0';
        document.body.appendChild(field);
        field.focus(); field.select();
        const succeeded = document.execCommand('copy'); field.remove();
        if (!succeeded) throw new Error('Clipboard unavailable');
      }
      note('Copied to clipboard');
    } catch { note('Copy unavailable in this browser'); }
  }
  function getSelectionFromEditable(el) {
    if (!el) return '';
    if ('selectionStart' in el && 'selectionEnd' in el) return el.value.slice(el.selectionStart, el.selectionEnd);
    return String(window.getSelection?.() || '');
  }
  function perform(action) {
    const {editable, link, product, image} = context;
    closeMenu();
    switch (action) {
      case 'home': window.kpmNavigate?.('index.html#/home') || (window.location.href='index.html#/home'); break;
      case 'full-menu': window.kpmNavigate?.('index.html#/menu') || (window.location.href='index.html#/menu'); break;
      case 'basket': document.querySelector('[data-open-cart]')?.click(); break;
      case 'whatsapp': window.open(defaultWhatsApp, '_blank', 'noopener,noreferrer'); break;
      case 'call': window.location.href = 'tel:+919759495433'; break;
      case 'maps': if(window.kpmNavigate) window.kpmNavigate('index.html#/connect/location'); else window.location.href='index.html#/connect/location'; break;
      case 'instagram': if(window.kpmNavigate) window.kpmNavigate('index.html#/connect/instagram'); else window.location.href='index.html#/connect/instagram'; break;
      case 'view-product': if (product) window.kpmNavigate?.(product.href) || (window.location.href=product.href); break;
      case 'open-link': if (link && isSafeWebUrl(link.href)) window.open(link.href, '_blank', 'noopener,noreferrer'); break;
      case 'open-image': if (image && isSafeWebUrl(image.src)) window.open(image.src, '_blank', 'noopener,noreferrer'); break;
      case 'copy-link': if (link) void copyValue(link.href); break;
      case 'copy-image-link': if (image) void copyValue(image.src); break;
      case 'copy-page': void copyValue(window.location.href); break;
      case 'select-all': if (editable?.select) { editable.focus(); editable.select(); } else if(editable) { const s = window.getSelection(); const r = document.createRange(); r.selectNodeContents(editable); s.removeAllRanges(); s.addRange(r); } break;
      case 'copy-selection': void copyValue(getSelectionFromEditable(editable)); break;
      case 'paste':
        if (editable && navigator.clipboard?.readText) {
          navigator.clipboard.readText().then(text => {
            if (!editable.isConnected) return;
            editable.focus();
            if (typeof editable.setRangeText === 'function') {
              const start = editable.selectionStart || 0;
              const end = editable.selectionEnd || start;
              editable.setRangeText(text, start, end, 'end');
              editable.dispatchEvent(new Event('input', {bubbles:true}));
            } else note('Use Ctrl+V to paste in this field');
          }).catch(() => note('Use Ctrl+V to paste in this field'));
        } break;
    }
  }

  document.addEventListener('contextmenu', event => {
    // Websites cannot override OS/browser privileged menus, but this
    // replaces the normal page contextmenu event for regular interactions.
    event.preventDefault();
    openAt(event.clientX, event.clientY, event.target);
  });
  menu.addEventListener('click', event => {
    const button = event.target.closest('[data-kpm-action]');
    if (button) { event.preventDefault(); perform(button.dataset.kpmAction); }
  });
  document.addEventListener('pointerdown', event => { if (!menu.hidden && !menu.contains(event.target)) closeMenu(); }, true);
  window.addEventListener('scroll', () => closeMenu(), {passive:true, capture:true});
  window.addEventListener('resize', () => closeMenu(), {passive:true});
  document.addEventListener('keydown', event => {
    if (event.key === 'Escape' && !menu.hidden) { event.preventDefault(); event.stopImmediatePropagation(); closeMenu(true); return; }
    if ((event.key === 'ContextMenu' || (event.shiftKey && event.key === 'F10'))) {
      event.preventDefault();
      const focus = document.activeElement || document.body;
      const rect = focus.getBoundingClientRect();
      openAt(Math.min(window.innerWidth - 20, rect.left + 20), Math.min(window.innerHeight - 20, rect.bottom + 6), focus, true);
      return;
    }
    if (menu.hidden) return;
    const buttons = [...menu.querySelectorAll('[role="menuitem"]')];
    const index = buttons.indexOf(document.activeElement);
    if (event.key === 'ArrowDown' || event.key === 'ArrowUp') {
      event.preventDefault();
      buttons[(index + (event.key === 'ArrowDown' ? 1 : -1) + buttons.length) % buttons.length]?.focus();
    } else if (event.key === 'Home') { event.preventDefault(); buttons[0]?.focus(); }
    else if (event.key === 'End') { event.preventDefault(); buttons[buttons.length-1]?.focus(); }
    else if (event.key === 'Tab') { closeMenu(); }
  }, true);
})();
